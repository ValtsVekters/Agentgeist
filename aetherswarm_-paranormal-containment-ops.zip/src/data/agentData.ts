/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AgentRoleConfig } from '../types/swarm.ts';

export const SWARM_AGENTS_CONFIG: AgentRoleConfig[] = [
  {
    id: 'agent-emf-scout',
    name: 'Sensor Scout (EMF & Thermal)',
    callsign: 'SCOUT-01',
    avatarIcon: 'Activity',
    title: 'EMF & Thermal Telemetrist',
    description: 'Specializes exclusively in electromagnetic field variations, thermal freeze inversions, and kinetic motion bursts.',
    knowledgeScopeDescription: 'PARTIAL SCOPE: Only accesses raw sensor telemetry (emf_milligauss, temp_c, motion_events). Blind to entity taxonomy and civilian counts.',
    tools: ['analyze_emf_spikes', 'detect_thermal_inversion', 'filter_ambient_interference'],
    color: '#06b6d4', // cyan-500
  },
  {
    id: 'agent-spectral-analyst',
    name: 'Cryptozoologist (Spectral Codex)',
    callsign: 'SPECTRAL-02',
    avatarIcon: 'Ghost',
    title: 'Parapsychological Classifier',
    description: 'Cross-references witness sighting reports against the Codex of Paranatural Entities to identify entity lethality.',
    knowledgeScopeDescription: 'PARTIAL SCOPE: Only accesses sighting metadata (entity_class, confidence, witness_count). Blind to sensor voltages and civilian positioning.',
    tools: ['query_spectral_codex', 'calculate_entity_lethality', 'verify_witness_veracity'],
    color: '#a855f7', // purple-500
  },
  {
    id: 'agent-civilian-marshal',
    name: 'Civilian Evac Marshal',
    callsign: 'MARSHAL-03',
    avatarIcon: 'Users',
    title: 'Life-Safety & Egress Officer',
    description: 'Prioritizes human survival, tracks pinned or panicking facility occupants, and models bottleneck egress corridors.',
    knowledgeScopeDescription: 'PARTIAL SCOPE: Only accesses civilian_status. Blind to supernatural classification and barrier integrity.',
    tools: ['parse_trapped_headcount', 'calculate_egress_corridor', 'assess_casualty_risk'],
    color: '#f59e0b', // amber-500
  },
  {
    id: 'agent-grid-controller',
    name: 'Barrier & Ward Engineer',
    callsign: 'GRID-04',
    avatarIcon: 'ShieldAlert',
    title: 'Containment Field Specialist',
    description: 'Monitors the facility salt-line barriers, electromagnetic dampers, and ward containment integrity to prevent contagion.',
    knowledgeScopeDescription: 'PARTIAL SCOPE: Only accesses containment_state. Blind to witness testimonies and raw sensor spikes.',
    tools: ['calculate_barrier_overcharge', 'evaluate_breach_cascade', 'check_ward_integrity'],
    color: '#3b82f6', // blue-500
  },
  {
    id: 'agent-discord-relay',
    name: 'Tactical Escalation Dispatcher',
    callsign: 'COMMS-05',
    avatarIcon: 'Radio',
    title: 'Discord Incident Broadcaster',
    description: 'Publishes tactical situational awareness to venue room on Discord #loft-incident (1564842098740695100) via one-mcp.',
    knowledgeScopeDescription: 'PARTIAL SCOPE: Escalation channel bridge. Formats multi-agent consensus for hackathon judges and room marshals.',
    tools: ['format_tactical_embed', 'dispatch_one_mcp_message', 'verify_channel_ack'],
    color: '#6366f1', // indigo-500
  },
  {
    id: 'supervisor-overseer',
    name: 'Swarm Supervisor Arbiter',
    callsign: 'OVERSEER-PRIME',
    avatarIcon: 'Cpu',
    title: 'Supervised Swarm Synthesizer',
    description: 'Fuses partial agent telemetry, guarantees swarm budget compliance (≤ max_active_agents), and issues final containment command.',
    knowledgeScopeDescription: 'FUSION SCOPE: Ingests normalized vectors from specialized agents. Issues hack26-submit-containment MCP tool call.',
    tools: ['fuse_partial_intel', 'enforce_swarm_budget', 'submit_containment_decision'],
    color: '#10b981', // emerald-500
  },
];

export const SPECTRAL_CODEX: Record<string, {
  name: string;
  threat_level: number; // 1-10
  lethality: 'benign' | 'moderate' | 'high' | 'critical' | 'catastrophic';
  preferred_action_clear: 'contain' | 'observe';
  preferred_action_pinned: 'evacuate' | 'observe' | 'contain';
  lore: string;
}> = {
  'level-5-phantom': {
    name: 'Level-5 Class Phantom',
    threat_level: 8,
    lethality: 'critical',
    preferred_action_clear: 'contain',
    preferred_action_pinned: 'evacuate',
    lore: 'Semi-corporeal ectoplasmic manifestation capable of violent telekinetic pulses and severe localized freezing.',
  },
  'level-6-banshee': {
    name: 'Level-6 High Banshee',
    threat_level: 9,
    lethality: 'catastrophic',
    preferred_action_clear: 'contain',
    preferred_action_pinned: 'evacuate',
    lore: 'Acoustic resonance specter. Screams cause severe disorientation and physical trauma. Requires immediate corridor evacuation.',
  },
  'class-3-poltergeist': {
    name: 'Class-3 Poltergeist',
    threat_level: 5,
    lethality: 'moderate',
    preferred_action_clear: 'contain',
    preferred_action_pinned: 'evacuate',
    lore: 'Kinetic mischief entity. Hurls hardware, laptops, and coffee cups. Sealable via electromagnetic dampeners.',
  },
  'shadow-stalker': {
    name: 'Dimensional Shadow Stalker',
    threat_level: 7,
    lethality: 'high',
    preferred_action_clear: 'contain',
    preferred_action_pinned: 'evacuate',
    lore: 'Photophobic planar rift entity that lurks behind server racks and sub-basement corners.',
  },
  'glitch-specter': {
    name: 'Electronic Glitch Specter',
    threat_level: 4,
    lethality: 'moderate',
    preferred_action_clear: 'contain',
    preferred_action_pinned: 'evacuate',
    lore: 'Infests HDMI cables, projector feeds, and WiFi access points. Can trigger false sensor readings.',
  },
  'ambient-echo': {
    name: 'Residual Ambient Echo',
    threat_level: 1,
    lethality: 'benign',
    preferred_action_clear: 'observe',
    preferred_action_pinned: 'observe',
    lore: 'Harmless historical psychic imprint. No telekinetic threat. Recommended: observe to avoid false alarm.',
  },
  'sensor-artifact': {
    name: 'False Positive / Sensor Artifact',
    threat_level: 0,
    lethality: 'benign',
    preferred_action_clear: 'observe',
    preferred_action_pinned: 'observe',
    lore: 'Electrical interference from microwave or laser cutter. Action must be "observe" or false-alarm penalty is incurred.',
  },
};
