/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FacilitySectorMeta } from '../types/swarm.ts';

export const FACILITY_NAME = 'AWS Builder Loft — San Francisco';
export const FACILITY_ID = 'aws-builder-loft-sf';
export const VENUE_DISCORD_CHANNEL = '#loft-incident';
export const VENUE_DISCORD_CHANNEL_ID = '1564842098740695100';

export const FACILITY_SECTORS: Record<string, FacilitySectorMeta> = {
  catering_coffee_bar: {
    id: 'catering_coffee_bar',
    name: 'Catering & Coffee Bar',
    coordinates: { x: 50, y: 50, w: 220, h: 140 },
    max_occupancy: 45,
    ward_generators: 2,
    corridor_connections: ['hackathon_pit_west', 'main_stage_auditorium'],
  },
  main_stage_auditorium: {
    id: 'main_stage_auditorium',
    name: 'Main Stage Auditorium',
    coordinates: { x: 300, y: 50, w: 280, h: 190 },
    max_occupancy: 180,
    ward_generators: 4,
    corridor_connections: ['catering_coffee_bar', 'executive_briefing_room', 'loading_dock_freight'],
  },
  server_room_pod_b: {
    id: 'server_room_pod_b',
    name: 'Server Room Pod B',
    coordinates: { x: 610, y: 50, w: 190, h: 140 },
    max_occupancy: 12,
    ward_generators: 3,
    corridor_connections: ['main_stage_auditorium', 'security_control_vault'],
  },
  hackathon_pit_west: {
    id: 'hackathon_pit_west',
    name: 'Hackathon Pit (West Wing)',
    coordinates: { x: 50, y: 220, w: 220, h: 210 },
    max_occupancy: 90,
    ward_generators: 2,
    corridor_connections: ['catering_coffee_bar', 'hardware_lab_basement'],
  },
  executive_briefing_room: {
    id: 'executive_briefing_room',
    name: 'Executive Briefing Suite',
    coordinates: { x: 300, y: 270, w: 280, h: 160 },
    max_occupancy: 25,
    ward_generators: 2,
    corridor_connections: ['main_stage_auditorium', 'security_control_vault'],
  },
  hardware_lab_basement: {
    id: 'hardware_lab_basement',
    name: 'Sub-Level Hardware Lab',
    coordinates: { x: 50, y: 460, w: 220, h: 140 },
    max_occupancy: 30,
    ward_generators: 3,
    corridor_connections: ['hackathon_pit_west', 'loading_dock_freight'],
  },
  loading_dock_freight: {
    id: 'loading_dock_freight',
    name: 'Freight Egress / Dock',
    coordinates: { x: 300, y: 460, w: 280, h: 140 },
    max_occupancy: 20,
    ward_generators: 1,
    corridor_connections: ['hardware_lab_basement', 'main_stage_auditorium', 'security_control_vault'],
  },
  security_control_vault: {
    id: 'security_control_vault',
    name: 'Security Vault & Ward Core',
    coordinates: { x: 610, y: 220, w: 190, h: 380 },
    max_occupancy: 15,
    ward_generators: 6,
    corridor_connections: ['server_room_pod_b', 'executive_briefing_room', 'loading_dock_freight'],
  },
};
