/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Exact input contract from Scenario MCP feed
export interface SensorData {
  emf_milligauss: number;
  temp_c: number;
  motion_events: number;
}

export interface SightingData {
  entity_class: string;
  confidence: number;
  witness_count: number;
}

export interface SectorReport {
  sector: string;
  sensors: SensorData;
  sighting: SightingData;
  civilian_status: string; // e.g. "4 pinned", "clear", "12 panicking", "2 injured"
  containment_state: 'breached' | 'holding' | 'critical' | 'compromised' | 'nominal';
}

export interface SwarmBudget {
  max_active_agents: number; // e.g. 8
  api_credits_remaining: number; // e.g. 45000
}

export interface EscalationChannel {
  app: 'discord';
  channel: '#loft-incident';
  channel_id?: string; // 1564842098740695100
  via: 'one-mcp';
}

export interface ScenarioTick {
  tick_id: number;
  facility_id: string; // e.g. "aws-builder-loft-sf"
  sector_reports: SectorReport[];
  swarm_budget: SwarmBudget;
  escalation_channel: EscalationChannel;
  timestamp?: number;
}

export type ContainmentAction = 'contain' | 'evacuate' | 'observe';

export interface ContainmentSubmission {
  team: string;
  tick_id: number;
  action: ContainmentAction;
}

export interface ContainmentJudgment {
  tick_id: number;
  action_submitted: ContainmentAction;
  action_called_for: ContainmentAction;
  score: number; // 0 to 1
  is_false_alarm: boolean;
  civilians_saved: number;
  civilians_lost: number;
  containment_speed_ms: number;
  reasoning: string;
  timestamp: number;
}

export interface ScoreboardTeam {
  team: string;
  rank: number;
  total_score: number;
  accuracy_rate: number; // 0-100%
  avg_latency_ms: number;
  false_alarm_count: number;
  false_alarm_rate: number; // 0-100%
  civilians_saved: number;
  civilians_lost: number;
  ticks_processed: number;
  budget_violations: number;
  last_action: ContainmentAction | null;
  status: 'active' | 'standby' | 'disqualified';
}

// Swarm Agents with Partial Individual Knowledge
export type AgentId = 
  | 'agent-emf-scout'
  | 'agent-spectral-analyst'
  | 'agent-civilian-marshal'
  | 'agent-grid-controller'
  | 'agent-discord-relay'
  | 'supervisor-overseer';

export interface AgentRoleConfig {
  id: AgentId;
  name: string;
  callsign: string;
  avatarIcon: string;
  title: string;
  description: string;
  knowledgeScopeDescription: string;
  tools: string[];
  color: string;
}

export interface AgentExecutionState {
  agent_id: AgentId;
  active: boolean;
  status: 'idle' | 'analyzing' | 'tool_executing' | 'dispatched' | 'error';
  last_tool_invoked?: string;
  partial_intel_received: Record<string, unknown>; // STRICTLY only their partial slice
  internal_hypothesis: string;
  recommended_action: ContainmentAction;
  confidence: number;
  execution_latency_ms: number;
}

export interface DiscordTacticalMessage {
  id: string;
  tick_id: number;
  timestamp: string;
  channel: string;
  channel_id: string;
  author: {
    name: string;
    bot: boolean;
    role: string;
    avatar_color: string;
  };
  content: string;
  embed: {
    title: string;
    color: number; // hex color for discord embeds (e.g. 0xef4444)
    description: string;
    fields: Array<{
      name: string;
      value: string;
      inline?: boolean;
    }>;
    footer: {
      text: string;
    };
  };
}

export interface SwarmDeliberationLog {
  id: string;
  tick_id: number;
  timestamp: number;
  active_agent_count: number;
  budget_max: number;
  credits_used: number;
  consensus_summary: string;
  supervisor_verdict: ContainmentAction;
  judgment?: ContainmentJudgment;
  agent_states: AgentExecutionState[];
}

export interface FacilitySectorMeta {
  id: string;
  name: string;
  coordinates: { x: number; y: number; w: number; h: number };
  max_occupancy: number;
  ward_generators: number;
  corridor_connections: string[];
}
