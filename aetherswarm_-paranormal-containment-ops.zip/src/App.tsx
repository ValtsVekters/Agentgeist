/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { TacticalHeader } from './components/TacticalHeader.tsx';
import { FacilityBlueprint } from './components/FacilityBlueprint.tsx';
import { SwarmKnowledgeGraph } from './components/SwarmKnowledgeGraph.tsx';
import { DiscordIncidentFeed } from './components/DiscordIncidentFeed.tsx';
import { VenueScoreboard } from './components/VenueScoreboard.tsx';
import { PythonMcpModal } from './components/PythonMcpModal.tsx';
import { TickInspectorModal } from './components/TickInspectorModal.tsx';
import { scenarioMcpService } from './services/mcpClient.ts';
import { swarmCoordinator } from './services/swarmCoordinator.ts';
import {
  ContainmentJudgment,
  DiscordTacticalMessage,
  ScenarioTick,
  ScoreboardTeam,
  SwarmDeliberationLog,
} from './types/swarm.ts';
import {
  Terminal,
  Activity,
  Layers,
  Radio,
  FileCode,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Info,
} from 'lucide-react';

export default function App() {
  const [teamHandle, setTeamHandle] = useState('team-04');
  const [currentTick, setCurrentTick] = useState<ScenarioTick | null>(null);
  const [deliberation, setDeliberation] = useState<SwarmDeliberationLog | null>(null);
  const [discordMessages, setDiscordMessages] = useState<DiscordTacticalMessage[]>([]);
  const [scoreboard, setScoreboard] = useState<ScoreboardTeam[]>([]);
  const [latestJudgment, setLatestJudgment] = useState<ContainmentJudgment | null>(null);

  // Simulation controls
  const [isRunning, setIsRunning] = useState(false);
  const [speed, setSpeed] = useState(1); // 1x, 2x, 5x
  const [activeAgentIds, setActiveAgentIds] = useState<string[]>([
    'agent-emf-scout',
    'agent-spectral-analyst',
    'agent-civilian-marshal',
    'agent-grid-controller',
    'agent-discord-relay',
  ]);

  // Inspection states
  const [selectedSectorId, setSelectedSectorId] = useState<string | null>('catering_coffee_bar');
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>('agent-emf-scout');
  const [activeTab, setActiveTab] = useState<'blueprint' | 'discord' | 'scoreboard'>('blueprint');

  // Modals
  const [isPythonModalOpen, setIsPythonModalOpen] = useState(false);
  const [isTickModalOpen, setIsTickModalOpen] = useState(false);

  const isProcessingRef = useRef(false);

  // Initial load
  useEffect(() => {
    scenarioMcpService.setTeamHandle(teamHandle);
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    const initialTick = await scenarioMcpService.getTick(142, 0);
    setCurrentTick(initialTick);
    const initialScoreboard = await scenarioMcpService.getScoreboard();
    setScoreboard(initialScoreboard);

    // Run initial swarm deliberation pass for tick 142
    runSwarmPass(initialTick, teamHandle);
  };

  const runSwarmPass = useCallback(
    async (tickToProcess: ScenarioTick, team: string) => {
      if (isProcessingRef.current) return;
      isProcessingRef.current = true;

      try {
        const result = await swarmCoordinator.executeSwarmDeliberation(tickToProcess, team);
        setDeliberation(result.deliberation);
        setLatestJudgment(result.deliberation.judgment || null);

        // Prepend new discord message to feed
        setDiscordMessages((prev) => [result.discordMessage, ...prev].slice(0, 30));

        // Update scoreboard
        const updatedScoreboard = await scenarioMcpService.getScoreboard();
        setScoreboard(updatedScoreboard);
      } catch (err) {
        console.error('Failed in swarm pass:', err);
      } finally {
        isProcessingRef.current = false;
      }
    },
    []
  );

  const handleStepTick = useCallback(async () => {
    const nextTickId = currentTick ? currentTick.tick_id + 1 : 142;
    const nextTick = await scenarioMcpService.getTick(nextTickId);
    setCurrentTick(nextTick);

    // Auto select first affected sector if available
    if (nextTick.sector_reports.length > 0) {
      setSelectedSectorId(nextTick.sector_reports[0].sector);
    }

    await runSwarmPass(nextTick, teamHandle);
  }, [currentTick, teamHandle, runSwarmPass]);

  const handleSelectScenario = async (scenarioIndex: number) => {
    const nextTickId = currentTick ? currentTick.tick_id + 1 : 142;
    const injectedTick = await scenarioMcpService.getTick(nextTickId, scenarioIndex);
    setCurrentTick(injectedTick);
    if (injectedTick.sector_reports.length > 0) {
      setSelectedSectorId(injectedTick.sector_reports[0].sector);
    }
    await runSwarmPass(injectedTick, teamHandle);
  };

  // Timer loop for auto-run
  useEffect(() => {
    if (!isRunning) return;

    const intervalTime = Math.max(600, Math.round(3200 / speed));
    const timer = setInterval(() => {
      handleStepTick();
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isRunning, speed, handleStepTick]);

  const handleTeamChange = (newTeam: string) => {
    setTeamHandle(newTeam);
    scenarioMcpService.setTeamHandle(newTeam);
    if (currentTick) {
      runSwarmPass(currentTick, newTeam);
    }
  };

  const handleToggleAgent = (agentId: string) => {
    setActiveAgentIds((prev) => {
      let updated: string[];
      if (prev.includes(agentId)) {
        updated = prev.filter((id) => id !== agentId);
      } else {
        updated = [...prev, agentId];
      }
      swarmCoordinator.setActiveAgents(updated);
      if (currentTick) {
        runSwarmPass(currentTick, teamHandle);
      }
      return updated;
    });
  };

  return (
    <div className="min-h-screen bg-[#080b11] text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Tactical Ops HUD Header */}
      <TacticalHeader
        tickId={currentTick?.tick_id || 142}
        teamHandle={teamHandle}
        onTeamChange={handleTeamChange}
        isRunning={isRunning}
        onToggleRun={() => setIsRunning(!isRunning)}
        onStepTick={handleStepTick}
        onReset={loadInitialData}
        speed={speed}
        onSpeedChange={setSpeed}
        budget={currentTick?.swarm_budget || { max_active_agents: 8, api_credits_remaining: 45000 }}
        activeAgentCount={activeAgentIds.length}
        onSelectScenario={handleSelectScenario}
        onOpenMcpModal={() => setIsTickModalOpen(true)}
        onOpenPythonModal={() => setIsPythonModalOpen(true)}
      />

      {/* Main Tactical Dashboard Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 flex flex-col gap-4">
        {/* Top Section: Swarm Knowledge Coordination Bus */}
        <section>
          <SwarmKnowledgeGraph
            deliberation={deliberation}
            currentTick={currentTick}
            activeAgentIds={activeAgentIds}
            onToggleAgent={handleToggleAgent}
            selectedAgentId={selectedAgentId}
            onSelectAgent={setSelectedAgentId}
          />
        </section>

        {/* Middle Section: Layout with Tabs for Facility Blueprint, Discord Incident Relay, and Venue Scoreboard */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          {/* Navigation View Tabs */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-lg text-xs font-mono">
            <button
              onClick={() => setActiveTab('blueprint')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-all ${
                activeTab === 'blueprint'
                  ? 'bg-emerald-600 text-white font-bold shadow-md shadow-emerald-950/60'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Facility Blueprint & Outbreak Grid</span>
            </button>

            <button
              onClick={() => setActiveTab('discord')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-all ${
                activeTab === 'discord'
                  ? 'bg-[#5865f2] text-white font-bold shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Discord #loft-incident (Judge Proof)</span>
              {discordMessages.length > 0 && (
                <span className="bg-emerald-500 text-slate-950 font-bold px-1.5 py-0.2 rounded-full text-[10px]">
                  {discordMessages.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('scoreboard')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-all ${
                activeTab === 'scoreboard'
                  ? 'bg-amber-600 text-white font-bold shadow-md shadow-amber-950/60'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Venue Scoreboard & Benchmarks</span>
            </button>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsTickModalOpen(true)}
              className="text-xs font-mono text-slate-400 hover:text-white flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 px-3 py-1.5 rounded-md transition-colors"
            >
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span>Inspect Raw Tick Contract</span>
            </button>
          </div>
        </div>

        {/* Tab Content Display */}
        <section className="grid grid-cols-1 gap-4">
          {activeTab === 'blueprint' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="lg:col-span-2">
                <FacilityBlueprint
                  tick={currentTick}
                  selectedSectorId={selectedSectorId}
                  onSelectSector={setSelectedSectorId}
                />
              </div>
              <div className="lg:col-span-1 flex flex-col gap-4">
                {/* Mini Discord Preview & Quick Evidence Card */}
                <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 flex flex-col flex-1">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs font-mono">
                    <span className="font-bold text-slate-200 flex items-center gap-1.5">
                      <Radio className="w-3.5 h-3.5 text-indigo-400" /> Live Discord Relay
                    </span>
                    <button
                      onClick={() => setActiveTab('discord')}
                      className="text-emerald-400 hover:underline text-[11px]"
                    >
                      Expand Feed &rarr;
                    </button>
                  </div>

                  {discordMessages[0] ? (
                    <div className="bg-[#2b2d31] p-3 rounded border-l-4 border-emerald-500 text-xs font-sans space-y-1.5">
                      <div className="text-[10px] text-[#949ba4] font-mono flex items-center justify-between">
                        <span>{discordMessages[0].channel}</span>
                        <span>{discordMessages[0].timestamp}</span>
                      </div>
                      <div className="font-bold text-white text-[11px]">
                        {discordMessages[0].embed.title}
                      </div>
                      <div className="text-[#b5bac1] text-[10px] line-clamp-3">
                        {discordMessages[0].embed.description}
                      </div>
                      <div className="text-[9px] text-[#949ba4] font-mono pt-1">
                        Proof: ID #{discordMessages[0].tick_id} • via one-mcp
                      </div>
                    </div>
                  ) : (
                    <div className="text-slate-500 text-xs font-mono py-8 text-center">
                      No broadcast dispatched yet.
                    </div>
                  )}

                  {/* Quick Venue Metric Card */}
                  <div className="mt-3 pt-3 border-t border-slate-800/80 text-xs font-mono space-y-1.5">
                    <div className="text-slate-400 text-[10px] uppercase font-bold">
                      Latest MCP Judgment Feedback:
                    </div>
                    {latestJudgment ? (
                      <div className="bg-slate-900 p-2.5 rounded border border-slate-800 text-[11px] space-y-1">
                        <div className="flex justify-between">
                          <span className="text-slate-400">Score:</span>
                          <span className="font-bold text-emerald-400">
                            {(latestJudgment.score * 100).toFixed(0)}% (Perfect Match)
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Speed:</span>
                          <span className="text-cyan-300 font-bold">{latestJudgment.containment_speed_ms} ms</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">False Alarm:</span>
                          <span className={latestJudgment.is_false_alarm ? 'text-red-400 font-bold' : 'text-emerald-400'}>
                            {latestJudgment.is_false_alarm ? 'YES (+1 Penalty)' : 'NO (Clean)'}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="text-slate-500 italic text-[11px]">Awaiting submission...</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'discord' && (
            <div className="h-[600px]">
              <DiscordIncidentFeed messages={discordMessages} teamHandle={teamHandle} />
            </div>
          )}

          {activeTab === 'scoreboard' && (
            <VenueScoreboard
              scoreboard={scoreboard}
              latestJudgment={latestJudgment}
              teamHandle={teamHandle}
            />
          )}
        </section>
      </main>

      {/* Footer Info */}
      <footer className="border-t border-slate-900 bg-slate-950 py-3 px-4 text-center text-xs font-mono text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <span>
            AetherSwarm Ops • Venue: <span className="text-slate-400">AWS Builder Loft SF</span> • Escalation: <span className="text-slate-400">#loft-incident</span>
          </span>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsPythonModalOpen(true)}
              className="hover:text-emerald-400 underline decoration-dotted"
            >
              CrewAI MCPServerHTTP Code
            </button>
            <span>•</span>
            <button
              onClick={() => setIsTickModalOpen(true)}
              className="hover:text-emerald-400 underline decoration-dotted"
            >
              Tick Schema & MCP Setup
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <PythonMcpModal
        isOpen={isPythonModalOpen}
        onClose={() => setIsPythonModalOpen(false)}
        teamHandle={teamHandle}
      />

      <TickInspectorModal
        isOpen={isTickModalOpen}
        onClose={() => setIsTickModalOpen(false)}
        tick={currentTick}
        onRefreshMcp={loadInitialData}
      />
    </div>
  );
}
