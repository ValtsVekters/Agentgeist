/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ContainmentAction,
  ContainmentJudgment,
  ScenarioTick,
  ScoreboardTeam,
  SectorReport,
} from '../types/swarm.ts';
import { FACILITY_ID, VENUE_DISCORD_CHANNEL, VENUE_DISCORD_CHANNEL_ID } from '../data/facilityData.ts';

// Initial Competitor Teams for the Venue Scoreboard
const INITIAL_LEADERBOARD: ScoreboardTeam[] = [
  {
    team: 'warden-ai',
    rank: 1,
    total_score: 890,
    accuracy_rate: 93.4,
    avg_latency_ms: 340,
    false_alarm_count: 2,
    false_alarm_rate: 4.8,
    civilians_saved: 42,
    civilians_lost: 1,
    ticks_processed: 38,
    budget_violations: 0,
    last_action: 'contain',
    status: 'active',
  },
  {
    team: 'team-04', // The user's swarm
    rank: 2,
    total_score: 875,
    accuracy_rate: 91.2,
    avg_latency_ms: 285,
    false_alarm_count: 1,
    false_alarm_rate: 3.1,
    civilians_saved: 36,
    civilians_lost: 0,
    ticks_processed: 32,
    budget_violations: 0,
    last_action: 'evacuate',
    status: 'active',
  },
  {
    team: 'specter-hunters',
    rank: 3,
    total_score: 795,
    accuracy_rate: 84.0,
    avg_latency_ms: 610,
    false_alarm_count: 5,
    false_alarm_rate: 14.2,
    civilians_saved: 28,
    civilians_lost: 4,
    ticks_processed: 35,
    budget_violations: 1,
    last_action: 'contain',
    status: 'active',
  },
  {
    team: 'lambda-swarm',
    rank: 4,
    total_score: 680,
    accuracy_rate: 76.5,
    avg_latency_ms: 820,
    false_alarm_count: 8,
    false_alarm_rate: 22.0,
    civilians_saved: 19,
    civilians_lost: 7,
    ticks_processed: 31,
    budget_violations: 2,
    last_action: 'observe',
    status: 'active',
  },
  {
    team: 'phantom-protocol',
    rank: 5,
    total_score: 540,
    accuracy_rate: 62.0,
    avg_latency_ms: 1140,
    false_alarm_count: 11,
    false_alarm_rate: 34.5,
    civilians_saved: 12,
    civilians_lost: 12,
    ticks_processed: 29,
    budget_violations: 0,
    last_action: 'evacuate',
    status: 'standby',
  },
];

// Curated benchmark scenario pool
const BENCHMARK_SCENARIOS: Array<{
  name: string;
  reports: SectorReport[];
  expected_action: ContainmentAction;
  civilians_at_risk: number;
  reasoning: string;
}> = [
  {
    name: 'Standard Prompt Tick (Coffee Bar Outbreak)',
    reports: [
      {
        sector: 'catering_coffee_bar',
        sensors: { emf_milligauss: 98, temp_c: -4, motion_events: 17 },
        sighting: { entity_class: 'level-5-phantom', confidence: 0.82, witness_count: 4 },
        civilian_status: '4 pinned',
        containment_state: 'breached',
      },
    ],
    expected_action: 'evacuate',
    civilians_at_risk: 4,
    reasoning: 'Level-5 phantom breached containment while 4 civilians are pinned and temperature is subzero (-4°C). Immediate evacuation required.',
  },
  {
    name: 'Auditorium Containment Breach (Empty Hall)',
    reports: [
      {
        sector: 'main_stage_auditorium',
        sensors: { emf_milligauss: 84, temp_c: 2, motion_events: 29 },
        sighting: { entity_class: 'class-3-poltergeist', confidence: 0.78, witness_count: 2 },
        civilian_status: 'clear',
        containment_state: 'breached',
      },
    ],
    expected_action: 'contain',
    civilians_at_risk: 0,
    reasoning: 'Poltergeist kinetic activity detected in empty hall. Hall is clear of civilians; ward barriers must seal the room to prevent egress.',
  },
  {
    name: 'Microwave / Server Harmonic False Alarm',
    reports: [
      {
        sector: 'server_room_pod_b',
        sensors: { emf_milligauss: 112, temp_c: 21, motion_events: 0 },
        sighting: { entity_class: 'sensor-artifact', confidence: 0.18, witness_count: 0 },
        civilian_status: 'clear',
        containment_state: 'nominal',
      },
    ],
    expected_action: 'observe',
    civilians_at_risk: 0,
    reasoning: 'High EMF is caused by server transformer harmonic at ambient temperature (21°C) with zero motion and no witnesses. An action of contain/evacuate is a false alarm.',
  },
  {
    name: 'Multi-Sector Breach: Basement & Freight Dock',
    reports: [
      {
        sector: 'hardware_lab_basement',
        sensors: { emf_milligauss: 104, temp_c: -6, motion_events: 34 },
        sighting: { entity_class: 'level-6-banshee', confidence: 0.89, witness_count: 6 },
        civilian_status: '7 pinned',
        containment_state: 'breached',
      },
      {
        sector: 'loading_dock_freight',
        sensors: { emf_milligauss: 42, temp_c: 8, motion_events: 9 },
        sighting: { entity_class: 'shadow-stalker', confidence: 0.65, witness_count: 2 },
        civilian_status: '3 evacuating',
        containment_state: 'critical',
      },
    ],
    expected_action: 'evacuate',
    civilians_at_risk: 10,
    reasoning: 'Dual sector contagion: Level-6 banshee in basement with 7 trapped makers and secondary shadow stalker blocking dock route. Emergency evacuation priority.',
  },
  {
    name: 'Executive Suite Poltergeist with Barriers Holding',
    reports: [
      {
        sector: 'executive_briefing_room',
        sensors: { emf_milligauss: 72, temp_c: 6, motion_events: 14 },
        sighting: { entity_class: 'class-3-poltergeist', confidence: 0.85, witness_count: 3 },
        civilian_status: 'clear',
        containment_state: 'holding',
      },
    ],
    expected_action: 'contain',
    civilians_at_risk: 0,
    reasoning: 'Salt-line wards are currently holding and room is vacant. Swarm must lock down grid barriers to reinforce containment before full breach.',
  },
  {
    name: 'Psychic Residual Echo (Low Threat)',
    reports: [
      {
        sector: 'hackathon_pit_west',
        sensors: { emf_milligauss: 28, temp_c: 19, motion_events: 4 },
        sighting: { entity_class: 'ambient-echo', confidence: 0.35, witness_count: 1 },
        civilian_status: '24 hacking peacefully',
        containment_state: 'nominal',
      },
    ],
    expected_action: 'observe',
    civilians_at_risk: 0,
    reasoning: 'Residual psychic echo with mild EMF elevation. Containment or evacuation would disrupt 24 engineers unnecessarily; observe protocol designated.',
  },
  {
    name: 'Multi-Sector Coordinated Swarm: Coffee Bar & Pit',
    reports: [
      {
        sector: 'catering_coffee_bar',
        sensors: { emf_milligauss: 68, temp_c: 4, motion_events: 19 },
        sighting: { entity_class: 'class-3-poltergeist', confidence: 0.74, witness_count: 5 },
        civilian_status: 'clear',
        containment_state: 'critical',
      },
      {
        sector: 'hackathon_pit_west',
        sensors: { emf_milligauss: 35, temp_c: 15, motion_events: 12 },
        sighting: { entity_class: 'glitch-specter', confidence: 0.52, witness_count: 3 },
        civilian_status: 'clear',
        containment_state: 'holding',
      },
    ],
    expected_action: 'contain',
    civilians_at_risk: 0,
    reasoning: 'Poltergeist spilling into coffee bar corridor with glitch specter in adjacent pit. No pinned civilians; execute synchronized dual-sector barrier containment.',
  },
];

export class ScenarioMcpService {
  private currentTickId: number = 142;
  private creditsRemaining: number = 45000;
  private teamHandle: string = 'team-04';
  private scoreboard: ScoreboardTeam[] = [...INITIAL_LEADERBOARD];
  private remoteMcpUrl: string = (import.meta as any).env?.VITE_SCENARIO_MCP || 'https://api.you.com/mcp/halloween-hack-26';
  private isUsingRemoteMcp: boolean = false;
  private tickHistory: Map<number, { tick: ScenarioTick; expected: ContainmentAction; civilians: number; reasoning: string }> = new Map();

  constructor() {
    // Seed initial tick 142
    this.seedTick(142, 0);
  }

  public setTeamHandle(team: string) {
    this.teamHandle = team.trim() || 'team-04';
    // Update scoreboard entry for team
    const exists = this.scoreboard.find((t) => t.team === this.teamHandle);
    if (!exists) {
      this.scoreboard.push({
        team: this.teamHandle,
        rank: this.scoreboard.length + 1,
        total_score: 800,
        accuracy_rate: 85.0,
        avg_latency_ms: 320,
        false_alarm_count: 1,
        false_alarm_rate: 3.5,
        civilians_saved: 20,
        civilians_lost: 0,
        ticks_processed: 20,
        budget_violations: 0,
        last_action: null,
        status: 'active',
      });
      this.recomputeRanks();
    }
  }

  public getTeamHandle(): string {
    return this.teamHandle;
  }

  public setRemoteMcpUrl(url: string, enabled: boolean) {
    this.remoteMcpUrl = url;
    this.isUsingRemoteMcp = enabled && Boolean(url);
  }

  public getRemoteMcpConfig() {
    return {
      url: this.remoteMcpUrl,
      enabled: this.isUsingRemoteMcp,
    };
  }

  private seedTick(tickId: number, scenarioIndex?: number) {
    const idx = scenarioIndex !== undefined ? scenarioIndex % BENCHMARK_SCENARIOS.length : (tickId - 142) % BENCHMARK_SCENARIOS.length;
    const base = BENCHMARK_SCENARIOS[Math.abs(idx)];

    const tick: ScenarioTick = {
      tick_id: tickId,
      facility_id: FACILITY_ID,
      sector_reports: JSON.parse(JSON.stringify(base.reports)),
      swarm_budget: {
        max_active_agents: 8,
        api_credits_remaining: Math.max(1000, this.creditsRemaining),
      },
      escalation_channel: {
        app: 'discord',
        channel: VENUE_DISCORD_CHANNEL,
        channel_id: VENUE_DISCORD_CHANNEL_ID,
        via: 'one-mcp',
      },
      timestamp: Date.now(),
    };

    this.tickHistory.set(tickId, {
      tick,
      expected: base.expected_action,
      civilians: base.civilians_at_risk,
      reasoning: base.reasoning,
    });

    return tick;
  }

  /**
   * Tool: hack26-get-tick
   * Pulls next incident tick from scenario feed.
   */
  public async getTick(requestedTickId?: number, scenarioOverrideIndex?: number): Promise<ScenarioTick> {
    const nextTickId = requestedTickId ?? this.currentTickId;
    this.currentTickId = nextTickId;

    // Deduct standard API tick token cost
    this.creditsRemaining = Math.max(0, this.creditsRemaining - 120);

    const generated = this.seedTick(nextTickId, scenarioOverrideIndex);
    return generated;
  }

  /**
   * Tool: hack26-submit-containment
   * Submits team decision: action = 'contain' | 'evacuate' | 'observe'
   * Returns instant judgment, score, and updates venue scoreboard.
   */
  public async submitContainment(
    team: string,
    tick_id: number,
    action: ContainmentAction,
    activeAgentCount: number = 5,
    measuredLatencyMs: number = 280
  ): Promise<ContainmentJudgment> {
    const cached = this.tickHistory.get(tick_id) || {
      tick: this.seedTick(tick_id),
      expected: 'evacuate' as ContainmentAction,
      civilians: 4,
      reasoning: 'Automated ground truth assessment.',
    };

    const isMatch = action === cached.expected;
    const isFalseAlarm = action !== 'observe' && cached.expected === 'observe';

    // Calculate score (0.0 to 1.0)
    let score = 0;
    let civSaved = 0;
    let civLost = 0;

    if (isMatch) {
      score = 1.0;
      if (cached.expected === 'evacuate') {
        civSaved = cached.civilians;
      } else if (cached.expected === 'contain') {
        civSaved = 2; // prevented spread
      }
    } else {
      // Partial credit or failure
      if (isFalseAlarm) {
        score = 0.05; // heavy penalty for false alarm
      } else if (cached.expected === 'evacuate' && action === 'contain') {
        score = 0.35; // containment attempted when evacuation was required
        civLost = Math.ceil(cached.civilians * 0.75);
        civSaved = cached.civilians - civLost;
      } else if (cached.expected === 'evacuate' && action === 'observe') {
        score = 0.0; // catastrophic delay
        civLost = cached.civilians;
      } else if (cached.expected === 'contain' && action === 'evacuate') {
        score = 0.70; // safe but unnecessary disruption
      } else {
        score = 0.20;
      }
    }

    // Check budget violation (exceeding max_active_agents is a scored failure)
    const budgetMax = cached.tick.swarm_budget.max_active_agents;
    const isOverBudget = activeAgentCount > budgetMax;
    if (isOverBudget) {
      score = Math.max(0, score - 0.5); // budget penalty
    }

    const judgment: ContainmentJudgment = {
      tick_id,
      action_submitted: action,
      action_called_for: cached.expected,
      score: Number(score.toFixed(2)),
      is_false_alarm: isFalseAlarm,
      civilians_saved: civSaved,
      civilians_lost: civLost,
      containment_speed_ms: measuredLatencyMs,
      reasoning: cached.reasoning,
      timestamp: Date.now(),
    };

    // Update scoreboard
    this.updateScoreboard(team, judgment, isOverBudget);

    // Prepare next tick id
    this.currentTickId = tick_id + 1;

    return judgment;
  }

  /**
   * Tool: hack26-get-scoreboard
   * Pulls current live standings from venue scoreboard.
   */
  public async getScoreboard(): Promise<ScoreboardTeam[]> {
    return [...this.scoreboard];
  }

  private updateScoreboard(team: string, judgment: ContainmentJudgment, budgetViolation: boolean) {
    let entry = this.scoreboard.find((t) => t.team === team);
    if (!entry) {
      entry = {
        team,
        rank: this.scoreboard.length + 1,
        total_score: 0,
        accuracy_rate: 0,
        avg_latency_ms: judgment.containment_speed_ms,
        false_alarm_count: 0,
        false_alarm_rate: 0,
        civilians_saved: 0,
        civilians_lost: 0,
        ticks_processed: 0,
        budget_violations: 0,
        last_action: null,
        status: 'active',
      };
      this.scoreboard.push(entry);
    }

    entry.ticks_processed += 1;
    entry.last_action = judgment.action_submitted;
    if (judgment.is_false_alarm) {
      entry.false_alarm_count += 1;
    }
    if (budgetViolation) {
      entry.budget_violations += 1;
    }
    entry.civilians_saved += judgment.civilians_saved;
    entry.civilians_lost += judgment.civilians_lost;

    // Incremental total score (each perfect tick awards up to 25 pts)
    const points = Math.round(judgment.score * 25);
    entry.total_score += points;

    // Recalculate averages
    entry.false_alarm_rate = Number(((entry.false_alarm_count / entry.ticks_processed) * 100).toFixed(1));
    const previousAcc = entry.accuracy_rate;
    const currentTickAccuracy = judgment.score * 100;
    entry.accuracy_rate = Number(((previousAcc * (entry.ticks_processed - 1) + currentTickAccuracy) / entry.ticks_processed).toFixed(1));
    entry.avg_latency_ms = Math.round(
      (entry.avg_latency_ms * (entry.ticks_processed - 1) + judgment.containment_speed_ms) / entry.ticks_processed
    );

    // Also simulate mild progress from competitor teams so the scoreboard feels alive
    this.simulateCompetitors();
    this.recomputeRanks();
  }

  private simulateCompetitors() {
    this.scoreboard.forEach((t) => {
      if (t.team !== this.teamHandle && t.status === 'active') {
        if (Math.random() > 0.45) {
          t.ticks_processed += 1;
          const won = Math.random() > 0.15;
          const pts = won ? Math.floor(Math.random() * 15 + 10) : Math.floor(Math.random() * 8);
          t.total_score += pts;
          if (won) {
            t.civilians_saved += Math.floor(Math.random() * 3 + 1);
          } else {
            if (Math.random() > 0.5) t.false_alarm_count += 1;
          }
          t.false_alarm_rate = Number(((t.false_alarm_count / t.ticks_processed) * 100).toFixed(1));
        }
      }
    });
  }

  private recomputeRanks() {
    this.scoreboard.sort((a, b) => {
      // Primary: total score, Secondary: fewer false alarms, Tertiary: latency
      if (b.total_score !== a.total_score) return b.total_score - a.total_score;
      if (a.false_alarm_rate !== b.false_alarm_rate) return a.false_alarm_rate - b.false_alarm_rate;
      return a.avg_latency_ms - b.avg_latency_ms;
    });

    this.scoreboard.forEach((team, index) => {
      team.rank = index + 1;
    });
  }
}

export const scenarioMcpService = new ScenarioMcpService();
