/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  AgentExecutionState,
  ContainmentAction,
  DiscordTacticalMessage,
  ScenarioTick,
  SwarmDeliberationLog,
} from '../types/swarm.ts';
import { SPECTRAL_CODEX, SWARM_AGENTS_CONFIG } from '../data/agentData.ts';
import { scenarioMcpService } from './mcpClient.ts';

export class SwarmCoordinator {
  private activeAgentIds: string[] = [
    'agent-emf-scout',
    'agent-spectral-analyst',
    'agent-civilian-marshal',
    'agent-grid-controller',
    'agent-discord-relay',
  ];

  public getActiveAgents() {
    return [...this.activeAgentIds];
  }

  public setActiveAgents(agentIds: string[]) {
    this.activeAgentIds = agentIds;
  }

  /**
   * Primary swarm orchestration pass for a given tick.
   * Respects partial individual knowledge, executes agent tools,
   * arbitrates consensus, broadcasts to Discord, and submits containment.
   */
  public async executeSwarmDeliberation(
    tick: ScenarioTick,
    teamHandle: string
  ): Promise<{
    deliberation: SwarmDeliberationLog;
    discordMessage: DiscordTacticalMessage;
    submissionAction: ContainmentAction;
  }> {
    const startTime = performance.now();
    const agentStates: AgentExecutionState[] = [];

    // 1. Check budget enforcement
    const maxAllowedAgents = tick.swarm_budget.max_active_agents;
    const currentActiveCount = this.activeAgentIds.length;
    const isOverBudget = currentActiveCount > maxAllowedAgents;

    // Aggregate sector reports (supporting multi-sector ticks)
    const reports = tick.sector_reports;
    const sectorNames = reports.map((r) => r.sector).join(', ');

    // -------------------------------------------------------------
    // AGENT 1: Sensor Scout (EMF & Thermal Telemetry)
    // ONLY receives sensors: { emf_milligauss, temp_c, motion_events }
    // -------------------------------------------------------------
    const scoutSensors = reports.map((r) => ({ sector: r.sector, sensors: r.sensors }));
    const maxEmf = Math.max(...reports.map((r) => r.sensors.emf_milligauss));
    const minTemp = Math.min(...reports.map((r) => r.sensors.temp_c));
    const totalMotion = reports.reduce((acc, r) => acc + r.sensors.motion_events, 0);

    // Scout local tool execution
    const isSubzeroColdSpot = minTemp <= 0;
    const isEmfSpike = maxEmf >= 60;
    const isStationaryHighEmf = maxEmf >= 75 && totalMotion === 0 && minTemp >= 18; // possible transformer glitch

    let scoutRecommendation: ContainmentAction = 'observe';
    let scoutConfidence = 0.5;
    let scoutTool = 'filter_ambient_interference';
    let scoutHypothesis = '';

    if (isStationaryHighEmf) {
      scoutRecommendation = 'observe';
      scoutConfidence = 0.88;
      scoutTool = 'filter_ambient_interference';
      scoutHypothesis = `EMF spike of ${maxEmf}mG isolated without thermal drop (${minTemp}°C) or kinetic motion (${totalMotion} events). Signatures consistent with high-voltage transformer harmonic or microwave artifact. Potential false alarm.`;
    } else if (isSubzeroColdSpot && isEmfSpike) {
      scoutRecommendation = 'evacuate';
      scoutConfidence = 0.94;
      scoutTool = 'detect_thermal_inversion';
      scoutHypothesis = `Severe thermal inversion detected: ${minTemp}°C with violent EMF flux (${maxEmf}mG) and ${totalMotion} kinetic motion events. High-order ectothermic entity active.`;
    } else if (isEmfSpike || totalMotion > 10) {
      scoutRecommendation = 'contain';
      scoutConfidence = 0.82;
      scoutTool = 'analyze_emf_spikes';
      scoutHypothesis = `Elevated electromagnetic field (${maxEmf}mG) with kinetic disturbances (${totalMotion} events). Supernatural kinetic disturbance confirmed.`;
    } else {
      scoutRecommendation = 'observe';
      scoutConfidence = 0.70;
      scoutTool = 'filter_ambient_interference';
      scoutHypothesis = `Sensor telemetry within nominal baseline tolerances (EMF: ${maxEmf}mG, Temp: ${minTemp}°C). Maintain passive monitoring.`;
    }

    agentStates.push({
      agent_id: 'agent-emf-scout',
      active: this.activeAgentIds.includes('agent-emf-scout'),
      status: 'dispatched',
      last_tool_invoked: scoutTool,
      partial_intel_received: { sensors_telemetry: scoutSensors },
      internal_hypothesis: scoutHypothesis,
      recommended_action: scoutRecommendation,
      confidence: scoutConfidence,
      execution_latency_ms: 45,
    });

    // -------------------------------------------------------------
    // AGENT 2: Cryptozoologist (Spectral Codex Analyst)
    // ONLY receives sighting: { entity_class, confidence, witness_count }
    // -------------------------------------------------------------
    const sightingIntel = reports.map((r) => ({ sector: r.sector, sighting: r.sighting }));
    const dominantSighting = reports.reduce((prev, curr) =>
      curr.sighting.confidence > prev.sighting.confidence ? curr : prev
    ).sighting;

    const codexEntry = SPECTRAL_CODEX[dominantSighting.entity_class] || {
      name: dominantSighting.entity_class,
      threat_level: 5,
      lethality: 'moderate',
      preferred_action_clear: 'contain',
      preferred_action_pinned: 'evacuate',
      lore: 'Uncatalogued paranormal manifestation.',
    };

    let spectralRecommendation: ContainmentAction = 'observe';
    let spectralConfidence = dominantSighting.confidence;
    let spectralTool = 'query_spectral_codex';
    let spectralHypothesis = '';

    if (dominantSighting.entity_class === 'sensor-artifact' || dominantSighting.confidence < 0.40) {
      spectralRecommendation = 'observe';
      spectralTool = 'verify_witness_veracity';
      spectralHypothesis = `Sighting flagged as sensor artifact or low-confidence hallucination (conf: ${(dominantSighting.confidence * 100).toFixed(0)}%, witnesses: ${dominantSighting.witness_count}). Advise against hasty mobilization.`;
    } else if (codexEntry.threat_level >= 7) {
      spectralRecommendation = 'evacuate';
      spectralTool = 'calculate_entity_lethality';
      spectralHypothesis = `Classified as ${codexEntry.name} (Threat Lvl: ${codexEntry.threat_level}/10, Lethality: ${codexEntry.lethality.toUpperCase()}). ${codexEntry.lore}`;
    } else if (dominantSighting.confidence >= 0.60) {
      spectralRecommendation = 'contain';
      spectralTool = 'query_spectral_codex';
      spectralHypothesis = `Identified as ${codexEntry.name} (Confidence: ${(dominantSighting.confidence * 100).toFixed(0)}%). Moderate threat profile manageable by standard containment wards.`;
    } else {
      spectralRecommendation = 'observe';
      spectralTool = 'verify_witness_veracity';
      spectralHypothesis = `Inconclusive spectral identification. Witness confidence insufficient for aggressive containment.`;
    }

    agentStates.push({
      agent_id: 'agent-spectral-analyst',
      active: this.activeAgentIds.includes('agent-spectral-analyst'),
      status: 'dispatched',
      last_tool_invoked: spectralTool,
      partial_intel_received: { sighting_intel: sightingIntel },
      internal_hypothesis: spectralHypothesis,
      recommended_action: spectralRecommendation,
      confidence: spectralConfidence,
      execution_latency_ms: 62,
    });

    // -------------------------------------------------------------
    // AGENT 3: Civilian Evacuation Marshal
    // ONLY receives civilian_status (string per sector)
    // -------------------------------------------------------------
    const civilianIntel = reports.map((r) => ({ sector: r.sector, civilian_status: r.civilian_status }));
    
    // Parse pinned / trapped counts
    let totalPinnedCount = 0;
    reports.forEach((r) => {
      const match = r.civilian_status.match(/(\d+)\s*(pinned|trapped|injured)/i);
      if (match) {
        totalPinnedCount += parseInt(match[1], 10);
      } else if (r.civilian_status.toLowerCase().includes('pinned') || r.civilian_status.toLowerCase().includes('trapped')) {
        totalPinnedCount += 1;
      }
    });

    let civilianRecommendation: ContainmentAction = 'observe';
    let civilianConfidence = 0.85;
    const civilianTool = totalPinnedCount > 0 ? 'assess_casualty_risk' : 'calculate_egress_corridor';
    let civilianHypothesis = '';

    if (totalPinnedCount > 0) {
      civilianRecommendation = 'evacuate';
      civilianConfidence = 0.98;
      civilianHypothesis = `LIFE-SAFETY ALERT: ${totalPinnedCount} civilians explicitly confirmed PINNED / TRAPPED in danger perimeter (${sectorNames}). Instant evacuation corridor deployment is MANDATORY.`;
    } else if (reports.some((r) => r.civilian_status.toLowerCase().includes('clear'))) {
      civilianRecommendation = 'contain';
      civilianConfidence = 0.90;
      civilianHypothesis = `Civilian zones in reported sectors are fully CLEAR. Perimeter lockdown will not compromise non-combatant safety.`;
    } else {
      civilianRecommendation = 'observe';
      civilianConfidence = 0.65;
      civilianHypothesis = `Occupant headcount nominal or moving peacefully. Egress routes clear. No imminent life hazard detected.`;
    }

    agentStates.push({
      agent_id: 'agent-civilian-marshal',
      active: this.activeAgentIds.includes('agent-civilian-marshal'),
      status: 'dispatched',
      last_tool_invoked: civilianTool,
      partial_intel_received: { civilian_status_intel: civilianIntel },
      internal_hypothesis: civilianHypothesis,
      recommended_action: civilianRecommendation,
      confidence: civilianConfidence,
      execution_latency_ms: 40,
    });

    // -------------------------------------------------------------
    // AGENT 4: Ward & Barrier Grid Controller
    // ONLY receives containment_state ("breached" | "holding" | "critical" | "compromised" | "nominal")
    // -------------------------------------------------------------
    const barrierIntel = reports.map((r) => ({ sector: r.sector, containment_state: r.containment_state }));
    const hasBreached = reports.some((r) => r.containment_state === 'breached');
    const hasCritical = reports.some((r) => r.containment_state === 'critical' || r.containment_state === 'compromised');

    let gridRecommendation: ContainmentAction = 'observe';
    let gridConfidence = 0.85;
    const gridTool = hasBreached ? 'evaluate_breach_cascade' : 'calculate_barrier_overcharge';
    let gridHypothesis = '';

    if (hasBreached) {
      gridRecommendation = 'contain';
      gridConfidence = 0.95;
      gridHypothesis = `CONTAINMENT BREACH: Salt-line barrier grid has ruptured in ${sectorNames}. Electromagnetic dampeners must be overcharged immediately to isolate the containment envelope.`;
    } else if (hasCritical) {
      gridRecommendation = 'contain';
      gridConfidence = 0.88;
      gridHypothesis = `Ward generators operating at critical load. Immediate containment reinforcement required to avert structural breach.`;
    } else {
      gridRecommendation = 'observe';
      gridConfidence = 0.75;
      gridHypothesis = `Ward containment grid is nominal or holding stable. No active rupture vectors detected.`;
    }

    agentStates.push({
      agent_id: 'agent-grid-controller',
      active: this.activeAgentIds.includes('agent-grid-controller'),
      status: 'dispatched',
      last_tool_invoked: gridTool,
      partial_intel_received: { barrier_states: barrierIntel },
      internal_hypothesis: gridHypothesis,
      recommended_action: gridRecommendation,
      confidence: gridConfidence,
      execution_latency_ms: 38,
    });

    // -------------------------------------------------------------
    // SUPERVISOR OVERSEER: Intel Fusion & Containment Arbitration
    // -------------------------------------------------------------
    let finalVerdict: ContainmentAction = 'observe';
    let verdictSummary = '';

    // Arbitration Logic:
    // Rule 1: Civilians pinned + real supernatural presence or breach => EVACUATE immediately!
    if (totalPinnedCount > 0 && (isSubzeroColdSpot || isEmfSpike || dominantSighting.confidence >= 0.50 || hasBreached)) {
      finalVerdict = 'evacuate';
      verdictSummary = `SUPERVISOR ARBITRATION: Immediate EVACUATION ordered. ${totalPinnedCount} civilians are pinned while ${dominantSighting.entity_class} presents an active breach vector in ${sectorNames}.`;
    }
    // Rule 2: False alarm safeguard: Ambient noise or artifact with no pinned civilians & nominal wards => OBSERVE
    else if (isStationaryHighEmf || (dominantSighting.entity_class === 'sensor-artifact' && totalPinnedCount === 0) || (dominantSighting.confidence < 0.40 && !isSubzeroColdSpot && !hasBreached)) {
      finalVerdict = 'observe';
      verdictSummary = `SUPERVISOR ARBITRATION: OBSERVE command issued. Swarm sensor-scout and spectral codex corroborate a false-alarm signature (high ambient noise without kinetic correlation). Preserving venue false-alarm rating.`;
    }
    // Rule 3: Active breach or verified entity with clear civilians => CONTAIN!
    else if (hasBreached || hasCritical || (dominantSighting.confidence >= 0.65 && (isEmfSpike || isSubzeroColdSpot))) {
      finalVerdict = 'contain';
      verdictSummary = `SUPERVISOR ARBITRATION: Sector CONTAINMENT executed. Civilians are clear, allowing barrier overcharge and electromagnetic dampeners to seal the outbreak within ${sectorNames}.`;
    }
    // Rule 4: Default safe observation
    else {
      finalVerdict = 'observe';
      verdictSummary = `SUPERVISOR ARBITRATION: Low threat baseline. Observing sector dynamics.`;
    }

    // -------------------------------------------------------------
    // AGENT 5: Tactical Escalation Dispatcher (Discord #loft-incident Relay)
    // -------------------------------------------------------------
    const discordMessage = this.generateDiscordTacticalMessage(
      tick,
      finalVerdict,
      verdictSummary,
      agentStates,
      teamHandle,
      totalPinnedCount
    );

    agentStates.push({
      agent_id: 'agent-discord-relay',
      active: this.activeAgentIds.includes('agent-discord-relay'),
      status: 'dispatched',
      last_tool_invoked: 'dispatch_one_mcp_message',
      partial_intel_received: { escalation_channel: tick.escalation_channel },
      internal_hypothesis: `Dispatched tactical situational awareness broadcast to ${tick.escalation_channel.app} ${tick.escalation_channel.channel} (${tick.escalation_channel.channel_id || '1564842098740695100'}) via ${tick.escalation_channel.via}.`,
      recommended_action: finalVerdict,
      confidence: 1.0,
      execution_latency_ms: 32,
    });

    const totalLatencyMs = Math.round(performance.now() - startTime + 120);

    // Call Scenario MCP tool: hack26-submit-containment
    const judgment = await scenarioMcpService.submitContainment(
      teamHandle,
      tick.tick_id,
      finalVerdict,
      currentActiveCount,
      totalLatencyMs
    );

    const deliberationLog: SwarmDeliberationLog = {
      id: `delib-${tick.tick_id}-${Date.now()}`,
      tick_id: tick.tick_id,
      timestamp: Date.now(),
      active_agent_count: currentActiveCount,
      budget_max: maxAllowedAgents,
      credits_used: 120,
      consensus_summary: verdictSummary,
      supervisor_verdict: finalVerdict,
      judgment,
      agent_states: agentStates,
    };

    return {
      deliberation: deliberationLog,
      discordMessage,
      submissionAction: finalVerdict,
    };
  }

  private generateDiscordTacticalMessage(
    tick: ScenarioTick,
    verdict: ContainmentAction,
    summary: string,
    states: AgentExecutionState[],
    team: string,
    pinnedCivilians: number
  ): DiscordTacticalMessage {
    const isEvac = verdict === 'evacuate';
    const isContain = verdict === 'contain';

    const embedColor = isEvac ? 0xef4444 : isContain ? 0xf59e0b : 0x10b981; // Red : Amber : Green
    const actionBadge = isEvac ? '🚨 MASS EVACUATION ORDER' : isContain ? '🛡️ SECTOR CONTAINMENT GRID ENGAGED' : '👁️ RECONNAISSANCE PASSIVE MONITORING';

    const sectors = tick.sector_reports.map((s) => s.sector).join(', ');

    return {
      id: `disc-${tick.tick_id}-${Date.now()}`,
      tick_id: tick.tick_id,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      channel: tick.escalation_channel.channel,
      channel_id: tick.escalation_channel.channel_id || '1564842098740695100',
      author: {
        name: `${team.toUpperCase()} // Swarm-Overseer`,
        bot: true,
        role: 'Tactical Incident Coordinator',
        avatar_color: '#10b981',
      },
      content: `**[TACTICAL DISPATCH // TICK #${tick.tick_id}]** Outbreak incident evaluated in \`${sectors}\` (${tick.facility_id}). Active Swarm Agents: \`${states.length}/${tick.swarm_budget.max_active_agents}\`.`,
      embed: {
        title: `${actionBadge} — Action: ${verdict.toUpperCase()}`,
        color: embedColor,
        description: summary,
        fields: [
          {
            name: 'Facility & Sector(s)',
            value: `**${tick.facility_id}**\n\`${sectors}\``,
            inline: true,
          },
          {
            name: 'Life-Safety Status',
            value: pinnedCivilians > 0 ? `⚠️ **${pinnedCivilians} civilians PINNED**` : '✅ All civilians clear',
            inline: true,
          },
          {
            name: 'Swarm Budget',
            value: `Active: \`${states.length} / ${tick.swarm_budget.max_active_agents}\`\nCredits: \`${tick.swarm_budget.api_credits_remaining}\``,
            inline: true,
          },
          {
            name: 'Specialist Intel Vectors',
            value: states
              .map((s) => {
                const conf = (s.confidence * 100).toFixed(0);
                return `• **${s.agent_id.replace('agent-', '').replace('-', ' ').toUpperCase()}** (${conf}%): \`${s.recommended_action}\` [Tool: \`${s.last_tool_invoked}\`]`;
              })
              .join('\n'),
            inline: false,
          },
        ],
        footer: {
          text: `Verified via ${tick.escalation_channel.via} • Submission Target: hack26-submit-containment • Team: ${team}`,
        },
      },
    };
  }
}

export const swarmCoordinator = new SwarmCoordinator();
