/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Shield,
  AlertOctagon,
  Flame,
  ThermometerSnowflake,
  Zap,
  Activity,
  UserX,
  Compass,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import { FACILITY_SECTORS } from '../data/facilityData.ts';
import { ScenarioTick, SectorReport } from '../types/swarm.ts';

interface FacilityBlueprintProps {
  tick: ScenarioTick | null;
  selectedSectorId: string | null;
  onSelectSector: (sectorId: string) => void;
}

export const FacilityBlueprint: React.FC<FacilityBlueprintProps> = ({
  tick,
  selectedSectorId,
  onSelectSector,
}) => {
  const [hoveredSectorId, setHoveredSectorId] = useState<string | null>(null);

  // Map of active sector reports
  const activeReportsMap = new Map<string, SectorReport>();
  if (tick?.sector_reports) {
    tick.sector_reports.forEach((r) => activeReportsMap.set(r.sector, r));
  }

  const getContainmentColor = (state?: string) => {
    switch (state) {
      case 'breached':
        return 'border-red-500 bg-red-950/40 text-red-300';
      case 'critical':
      case 'compromised':
        return 'border-amber-500 bg-amber-950/40 text-amber-300';
      case 'holding':
        return 'border-cyan-500 bg-cyan-950/30 text-cyan-300';
      case 'nominal':
      default:
        return 'border-slate-800 bg-slate-900/60 text-slate-400';
    }
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 flex flex-col relative overflow-hidden">
      {/* Blueprint Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <h2 className="text-sm font-semibold tracking-wide text-slate-100 font-mono flex items-center gap-2">
            FACILITY TACTICAL BLUEPRINT // AWS BUILDER LOFT SF
          </h2>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-500" /> Breached
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400" /> Wards Holding
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-slate-600" /> Nominal
          </span>
        </div>
      </div>

      {/* Blueprint Grid Canvas */}
      <div className="relative w-full aspect-[16/10] bg-slate-950/80 rounded border border-slate-800/60 tactical-grid-bg p-3 overflow-hidden">
        {/* Architectural Corridor Lines */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-40">
          {/* Corridor lines connecting sectors */}
          <line x1="22%" y1="18%" x2="50%" y2="18%" stroke="#0284c7" strokeWidth="2" strokeDasharray="4 4" />
          <line x1="50%" y1="18%" x2="78%" y2="18%" stroke="#0284c7" strokeWidth="2" strokeDasharray="4 4" />
          <line x1="22%" y1="18%" x2="22%" y2="48%" stroke="#0284c7" strokeWidth="2" strokeDasharray="4 4" />
          <line x1="22%" y1="48%" x2="22%" y2="78%" stroke="#0284c7" strokeWidth="2" strokeDasharray="4 4" />
          <line x1="50%" y1="18%" x2="50%" y2="48%" stroke="#0284c7" strokeWidth="2" strokeDasharray="4 4" />
          <line x1="50%" y1="48%" x2="50%" y2="78%" stroke="#0284c7" strokeWidth="2" strokeDasharray="4 4" />
          <line x1="78%" y1="18%" x2="78%" y2="50%" stroke="#0284c7" strokeWidth="2" strokeDasharray="4 4" />
          <line x1="50%" y1="78%" x2="78%" y2="50%" stroke="#0284c7" strokeWidth="2" strokeDasharray="4 4" />
        </svg>

        {/* Sectors Grid Layout */}
        <div className="relative w-full h-full grid grid-cols-12 grid-rows-6 gap-2.5 z-10">
          {/* 1. Catering & Coffee Bar (Top Left) */}
          <SectorCard
            sectorId="catering_coffee_bar"
            gridClass="col-span-4 row-span-2"
            report={activeReportsMap.get('catering_coffee_bar')}
            isSelected={selectedSectorId === 'catering_coffee_bar'}
            onSelect={() => onSelectSector('catering_coffee_bar')}
            onHover={setHoveredSectorId}
          />

          {/* 2. Main Stage Auditorium (Top Center) */}
          <SectorCard
            sectorId="main_stage_auditorium"
            gridClass="col-span-5 row-span-3"
            report={activeReportsMap.get('main_stage_auditorium')}
            isSelected={selectedSectorId === 'main_stage_auditorium'}
            onSelect={() => onSelectSector('main_stage_auditorium')}
            onHover={setHoveredSectorId}
          />

          {/* 3. Server Room Pod B (Top Right) */}
          <SectorCard
            sectorId="server_room_pod_b"
            gridClass="col-span-3 row-span-2"
            report={activeReportsMap.get('server_room_pod_b')}
            isSelected={selectedSectorId === 'server_room_pod_b'}
            onSelect={() => onSelectSector('server_room_pod_b')}
            onHover={setHoveredSectorId}
          />

          {/* 4. Hackathon Pit (West Wing) */}
          <SectorCard
            sectorId="hackathon_pit_west"
            gridClass="col-span-4 row-span-2"
            report={activeReportsMap.get('hackathon_pit_west')}
            isSelected={selectedSectorId === 'hackathon_pit_west'}
            onSelect={() => onSelectSector('hackathon_pit_west')}
            onHover={setHoveredSectorId}
          />

          {/* 5. Security Control Vault & Ward Core (Right) */}
          <SectorCard
            sectorId="security_control_vault"
            gridClass="col-span-3 row-span-4"
            report={activeReportsMap.get('security_control_vault')}
            isSelected={selectedSectorId === 'security_control_vault'}
            onSelect={() => onSelectSector('security_control_vault')}
            onHover={setHoveredSectorId}
          />

          {/* 6. Executive Briefing Suite (Center Bottom) */}
          <SectorCard
            sectorId="executive_briefing_room"
            gridClass="col-span-5 row-span-1"
            report={activeReportsMap.get('executive_briefing_room')}
            isSelected={selectedSectorId === 'executive_briefing_room'}
            onSelect={() => onSelectSector('executive_briefing_room')}
            onHover={setHoveredSectorId}
          />

          {/* 7. Sub-Level Hardware Lab (Bottom Left) */}
          <SectorCard
            sectorId="hardware_lab_basement"
            gridClass="col-span-4 row-span-2"
            report={activeReportsMap.get('hardware_lab_basement')}
            isSelected={selectedSectorId === 'hardware_lab_basement'}
            onSelect={() => onSelectSector('hardware_lab_basement')}
            onHover={setHoveredSectorId}
          />

          {/* 8. Freight Egress / Dock (Bottom Center) */}
          <SectorCard
            sectorId="loading_dock_freight"
            gridClass="col-span-5 row-span-2"
            report={activeReportsMap.get('loading_dock_freight')}
            isSelected={selectedSectorId === 'loading_dock_freight'}
            onSelect={() => onSelectSector('loading_dock_freight')}
            onHover={setHoveredSectorId}
          />
        </div>

        {/* Ambient Radar Sweep Overlay */}
        <div className="absolute -top-32 -left-32 w-80 h-80 rounded-full border border-emerald-500/10 pointer-events-none animate-radar" />
      </div>

      {/* Selected Sector Diagnostic Bar */}
      {selectedSectorId && (
        <div className="mt-3 p-3 bg-slate-900 border border-slate-800 rounded-md">
          {activeReportsMap.has(selectedSectorId) ? (
            <SectorDiagnosticView report={activeReportsMap.get(selectedSectorId)!} />
          ) : (
            <div className="text-xs text-slate-400 font-mono flex items-center justify-between">
              <div>
                <span className="font-semibold text-slate-200">
                  {FACILITY_SECTORS[selectedSectorId]?.name || selectedSectorId}
                </span>{' '}
                — Sector Status: <span className="text-emerald-400 font-bold">NOMINAL / SECURED</span>. No active anomaly reported in Tick #{tick?.tick_id}.
              </div>
              <span className="text-slate-500">Salt-Ward Grid: 100% Integrity</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

interface SectorCardProps {
  sectorId: string;
  gridClass: string;
  report?: SectorReport;
  isSelected: boolean;
  onSelect: () => void;
  onHover: (id: string | null) => void;
}

const SectorCard: React.FC<SectorCardProps> = ({
  sectorId,
  gridClass,
  report,
  isSelected,
  onSelect,
  onHover,
}) => {
  const meta = FACILITY_SECTORS[sectorId];
  const hasOutbreak = Boolean(report);
  const isBreached = report?.containment_state === 'breached';
  const isCritical = report?.containment_state === 'critical' || report?.containment_state === 'compromised';
  const hasPinnedCivilians = report?.civilian_status?.toLowerCase().includes('pinned') || report?.civilian_status?.toLowerCase().includes('trapped');

  // Color classes
  let borderClass = 'border-slate-800 bg-slate-900/50 hover:border-slate-700';
  let badgeClass = 'text-slate-400 bg-slate-800/60';

  if (hasOutbreak) {
    if (isBreached) {
      borderClass = 'border-red-500/80 bg-red-950/30 ring-1 ring-red-500/50 animate-pulse';
      badgeClass = 'text-red-400 bg-red-950 border border-red-800/80';
    } else if (isCritical) {
      borderClass = 'border-amber-500/80 bg-amber-950/30 ring-1 ring-amber-500/50';
      badgeClass = 'text-amber-400 bg-amber-950 border border-amber-800/80';
    } else {
      borderClass = 'border-cyan-500/80 bg-cyan-950/30';
      badgeClass = 'text-cyan-400 bg-cyan-950 border border-cyan-800/80';
    }
  }

  if (isSelected) {
    borderClass += ' outline outline-2 outline-emerald-400';
  }

  return (
    <div
      onClick={onSelect}
      onMouseEnter={() => onHover(sectorId)}
      onMouseLeave={() => onHover(null)}
      className={`relative rounded border p-2 flex flex-col justify-between cursor-pointer transition-all ${borderClass} ${gridClass}`}
    >
      {/* Top Header of Sector */}
      <div className="flex items-start justify-between gap-1">
        <div className="min-w-0">
          <div className="text-[11px] font-bold text-slate-200 truncate font-mono">
            {meta?.name || sectorId}
          </div>
          <div className="text-[9px] text-slate-500 font-mono uppercase tracking-wider">
            ID: {sectorId}
          </div>
        </div>

        {/* State Badge */}
        {hasOutbreak ? (
          <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded uppercase font-semibold ${badgeClass}`}>
            {report?.containment_state}
          </span>
        ) : (
          <span className="text-[9px] font-mono text-slate-500">Nominal</span>
        )}
      </div>

      {/* Middle: Paranormal Anomaly Indicators */}
      {hasOutbreak && report && (
        <div className="my-1 flex flex-wrap gap-1.5 items-center">
          {/* Entity Tag */}
          <div className="flex items-center gap-1 text-[10px] text-purple-300 font-mono bg-purple-950/50 px-1.5 py-0.5 rounded border border-purple-800/60 truncate">
            <span className="font-semibold">{report.sighting.entity_class}</span>
            <span className="text-purple-400">({(report.sighting.confidence * 100).toFixed(0)}%)</span>
          </div>

          {/* Subzero Cold Spot indicator */}
          {report.sensors.temp_c <= 0 && (
            <div className="flex items-center gap-1 text-[10px] text-cyan-300 font-mono bg-cyan-950/60 px-1 py-0.5 rounded border border-cyan-800/80">
              <ThermometerSnowflake className="w-3 h-3 text-cyan-400" />
              <span>{report.sensors.temp_c}°C</span>
            </div>
          )}

          {/* EMF Spike indicator */}
          {report.sensors.emf_milligauss >= 60 && (
            <div className="flex items-center gap-1 text-[10px] text-amber-300 font-mono bg-amber-950/60 px-1 py-0.5 rounded border border-amber-800/80">
              <Zap className="w-3 h-3 text-amber-400" />
              <span>{report.sensors.emf_milligauss} mG</span>
            </div>
          )}

          {/* Pinned Civilians */}
          {hasPinnedCivilians && (
            <div className="flex items-center gap-1 text-[10px] text-red-200 font-bold font-mono bg-red-900/80 px-1.5 py-0.5 rounded border border-red-600 animate-bounce">
              <UserX className="w-3 h-3 text-red-300" />
              <span>{report.civilian_status}</span>
            </div>
          )}
        </div>
      )}

      {/* Bottom Telemetry Mini-Ticker */}
      <div className="flex items-center justify-between text-[9px] font-mono text-slate-400 border-t border-slate-800/60 pt-1 mt-auto">
        <span>Ward Gens: {meta?.ward_generators ?? 2}</span>
        {hasOutbreak && report ? (
          <span className="text-slate-300">
            Mot: {report.sensors.motion_events} | Wits: {report.sighting.witness_count}
          </span>
        ) : (
          <span className="text-emerald-500/70">Wards 100%</span>
        )}
      </div>
    </div>
  );
};

const SectorDiagnosticView: React.FC<{ report: SectorReport }> = ({ report }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-mono">
      {/* 1. Sensors Telemetry */}
      <div className="bg-slate-950/70 border border-slate-800 p-2 rounded">
        <div className="text-[10px] text-cyan-400 font-semibold uppercase tracking-wider mb-1 flex items-center gap-1">
          <Activity className="w-3 h-3" /> Raw Sensors (Scout Slice)
        </div>
        <div className="space-y-0.5 text-slate-300">
          <div>EMF: <span className="font-bold text-amber-300">{report.sensors.emf_milligauss} mG</span></div>
          <div>Temp: <span className={`font-bold ${report.sensors.temp_c <= 0 ? 'text-cyan-300' : 'text-slate-200'}`}>{report.sensors.temp_c}°C</span></div>
          <div>Motion Events: <span className="text-slate-200">{report.sensors.motion_events}</span></div>
        </div>
      </div>

      {/* 2. Sighting Data */}
      <div className="bg-slate-950/70 border border-slate-800 p-2 rounded">
        <div className="text-[10px] text-purple-400 font-semibold uppercase tracking-wider mb-1 flex items-center gap-1">
          <Zap className="w-3 h-3" /> Sighting (Analyst Slice)
        </div>
        <div className="space-y-0.5 text-slate-300">
          <div>Class: <span className="font-bold text-purple-300">{report.sighting.entity_class}</span></div>
          <div>Confidence: <span className="font-bold text-purple-300">{(report.sighting.confidence * 100).toFixed(0)}%</span></div>
          <div>Witnesses: <span className="text-slate-200">{report.sighting.witness_count}</span></div>
        </div>
      </div>

      {/* 3. Civilian Life-Safety */}
      <div className="bg-slate-950/70 border border-slate-800 p-2 rounded">
        <div className="text-[10px] text-amber-400 font-semibold uppercase tracking-wider mb-1 flex items-center gap-1">
          <UserX className="w-3 h-3" /> Life-Safety (Marshal Slice)
        </div>
        <div className="space-y-0.5 text-slate-300">
          <div>Status: <span className="font-bold text-amber-300">{report.civilian_status}</span></div>
          <div>Egress Priority: <span className="text-slate-300">{report.civilian_status.toLowerCase().includes('pinned') ? 'CRITICAL EVAC' : 'NORMAL'}</span></div>
        </div>
      </div>

      {/* 4. Containment Ward State */}
      <div className="bg-slate-950/70 border border-slate-800 p-2 rounded">
        <div className="text-[10px] text-emerald-400 font-semibold uppercase tracking-wider mb-1 flex items-center gap-1">
          <Shield className="w-3 h-3" /> Barrier State (Engineer Slice)
        </div>
        <div className="space-y-0.5 text-slate-300">
          <div>Grid State: <span className="font-bold uppercase text-red-400">{report.containment_state}</span></div>
          <div>Action Called: <span className="text-slate-200">{report.civilian_status.includes('pinned') ? 'EVACUATE' : 'CONTAIN'}</span></div>
        </div>
      </div>
    </div>
  );
};
