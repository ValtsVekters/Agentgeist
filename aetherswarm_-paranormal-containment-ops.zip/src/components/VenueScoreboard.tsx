/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Trophy,
  Zap,
  ShieldCheck,
  AlertTriangle,
  UserCheck,
  UserX,
  Gauge,
  Clock,
  Sparkles,
  Award,
} from 'lucide-react';
import { ContainmentJudgment, ScoreboardTeam } from '../types/swarm.ts';

interface VenueScoreboardProps {
  scoreboard: ScoreboardTeam[];
  latestJudgment: ContainmentJudgment | null;
  teamHandle: string;
}

export const VenueScoreboard: React.FC<VenueScoreboardProps> = ({
  scoreboard,
  latestJudgment,
  teamHandle,
}) => {
  const currentTeamData = scoreboard.find((t) => t.team === teamHandle);

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 flex flex-col gap-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-slate-800 gap-2">
        <div className="flex items-center gap-2">
          <Trophy className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-semibold tracking-wide text-slate-100 font-mono">
            VENUE SCOREBOARD // REAL-TIME HACKATHON LEADERBOARD
          </h2>
        </div>
        <div className="text-xs text-slate-400 font-mono">
          Live feed via <span className="text-emerald-400">hack26-get-scoreboard</span>
        </div>
      </div>

      {/* Instant Judgment Banner from latest submission */}
      {latestJudgment && (
        <div
          className={`rounded-lg border p-3 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs font-mono transition-all ${
            latestJudgment.score >= 0.8
              ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-200'
              : latestJudgment.is_false_alarm
              ? 'bg-red-950/40 border-red-500/60 text-red-200'
              : 'bg-amber-950/40 border-amber-500/60 text-amber-200'
          }`}
        >
          {/* Left: Score & Verdict */}
          <div className="flex items-center gap-3">
            <div
              className={`w-12 h-12 rounded-lg flex flex-col items-center justify-center font-bold font-mono border ${
                latestJudgment.score >= 0.8
                  ? 'bg-emerald-900/60 border-emerald-500 text-emerald-300'
                  : 'bg-slate-900 border-slate-700 text-slate-200'
              }`}
            >
              <span className="text-base leading-none">{(latestJudgment.score * 100).toFixed(0)}</span>
              <span className="text-[9px] uppercase font-normal text-slate-400">PTS</span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-slate-400 uppercase text-[11px]">TICK #{latestJudgment.tick_id} JUDGMENT:</span>
                <span className="font-bold text-white uppercase text-xs">
                  {latestJudgment.action_submitted === latestJudgment.action_called_for
                    ? 'VERDICT MATCH'
                    : 'MISMATCH'}
                </span>
                {latestJudgment.is_false_alarm && (
                  <span className="text-[10px] bg-red-900 text-red-300 px-1.5 py-0.5 rounded border border-red-700 font-bold uppercase">
                    FALSE ALARM!
                  </span>
                )}
              </div>
              <div className="text-[11px] text-slate-300 mt-0.5">
                Submitted: <span className="font-bold uppercase text-white">{latestJudgment.action_submitted}</span> |
                Called For:{' '}
                <span className="font-bold uppercase text-white">{latestJudgment.action_called_for}</span>
              </div>
              <div className="text-[10px] text-slate-400 italic mt-0.5 max-w-xl">
                {latestJudgment.reasoning}
              </div>
            </div>
          </div>

          {/* Right: Containment Speed & Civilians */}
          <div className="flex items-center gap-4 text-xs font-mono self-end md:self-center shrink-0">
            <div className="flex items-center gap-1.5 bg-slate-950/60 px-2.5 py-1.5 rounded border border-slate-800">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>Speed: <strong className="text-cyan-300">{latestJudgment.containment_speed_ms}ms</strong></span>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-950/60 px-2.5 py-1.5 rounded border border-slate-800">
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Saved: <strong className="text-emerald-300">+{latestJudgment.civilians_saved}</strong></span>
              {latestJudgment.civilians_lost > 0 && (
                <span className="text-red-400 font-bold">(-{latestJudgment.civilians_lost})</span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Team Metrics Summary Cards */}
      {currentTeamData && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="bg-slate-900/60 border border-slate-800 p-2.5 rounded text-xs font-mono">
            <div className="text-slate-400 text-[10px] uppercase flex items-center justify-between">
              <span>Overall Score</span>
              <Award className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="text-lg font-bold text-white mt-1">
              {currentTeamData.total_score} <span className="text-xs text-slate-500 font-normal">pts</span>
            </div>
            <div className="text-[10px] text-emerald-400 mt-0.5">
              Rank #{currentTeamData.rank} on Leaderboard
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-2.5 rounded text-xs font-mono">
            <div className="text-slate-400 text-[10px] uppercase flex items-center justify-between">
              <span>Containment Speed</span>
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="text-lg font-bold text-cyan-300 mt-1">
              {currentTeamData.avg_latency_ms} <span className="text-xs text-slate-500 font-normal">ms</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Sub-second response
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-2.5 rounded text-xs font-mono">
            <div className="text-slate-400 text-[10px] uppercase flex items-center justify-between">
              <span>False-Alarm Rate</span>
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div
              className={`text-lg font-bold mt-1 ${
                currentTeamData.false_alarm_rate > 10 ? 'text-red-400' : 'text-emerald-300'
              }`}
            >
              {currentTeamData.false_alarm_rate}%
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {currentTeamData.false_alarm_count} alarms logged
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-2.5 rounded text-xs font-mono">
            <div className="text-slate-400 text-[10px] uppercase flex items-center justify-between">
              <span>Civilians Saved</span>
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-lg font-bold text-emerald-300 mt-1">
              {currentTeamData.civilians_saved}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Lost: {currentTeamData.civilians_lost}
            </div>
          </div>
        </div>
      )}

      {/* Leaderboard Table */}
      <div className="overflow-x-auto rounded border border-slate-800">
        <table className="w-full text-left text-xs font-mono border-collapse">
          <thead>
            <tr className="bg-slate-900/80 text-slate-400 border-b border-slate-800">
              <th className="py-2.5 px-3">Rank</th>
              <th className="py-2.5 px-3">Team</th>
              <th className="py-2.5 px-3 text-right">Score</th>
              <th className="py-2.5 px-3 text-right">Containment Speed</th>
              <th className="py-2.5 px-3 text-right">False Alarm Rate</th>
              <th className="py-2.5 px-3 text-right">Civilians Saved</th>
              <th className="py-2.5 px-3 text-right">Accuracy</th>
              <th className="py-2.5 px-3 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-300">
            {scoreboard.map((team) => {
              const isUserTeam = team.team === teamHandle;

              return (
                <tr
                  key={team.team}
                  className={`transition-colors ${
                    isUserTeam
                      ? 'bg-emerald-950/40 hover:bg-emerald-950/60 text-white font-semibold'
                      : 'hover:bg-slate-900/40 text-slate-300'
                  }`}
                >
                  <td className="py-2.5 px-3">
                    <span
                      className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[11px] font-bold ${
                        team.rank === 1
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                          : team.rank === 2
                          ? 'bg-slate-300/20 text-slate-200 border border-slate-400/50'
                          : team.rank === 3
                          ? 'bg-amber-700/20 text-amber-400 border border-amber-700/50'
                          : 'text-slate-500'
                      }`}
                    >
                      {team.rank}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold">{team.team}</span>
                      {isUserTeam && (
                        <span className="text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-1 rounded uppercase">
                          YOUR SWARM
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-amber-300">
                    {team.total_score}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-cyan-300">
                    {team.avg_latency_ms} ms
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <span
                      className={`${
                        team.false_alarm_rate > 15 ? 'text-red-400 font-bold' : 'text-slate-300'
                      }`}
                    >
                      {team.false_alarm_rate}% ({team.false_alarm_count})
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-400">
                    {team.civilians_saved} <span className="text-slate-500 text-[10px]">(-{team.civilians_lost})</span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono">
                    {team.accuracy_rate}%
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span
                      className={`text-[9px] px-2 py-0.5 rounded font-mono uppercase font-semibold ${
                        team.status === 'active'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {team.status}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
