/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Terminal,
  AlertCircle,
  FileCode,
  ExternalLink,
  ShieldAlert,
} from 'lucide-react';

interface PythonMcpModalProps {
  isOpen: boolean;
  onClose: () => void;
  teamHandle: string;
}

export const PythonMcpModal: React.FC<PythonMcpModalProps> = ({
  isOpen,
  onClose,
  teamHandle,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const pythonScript = `"""
AetherSwarm: Paranormal Containment Swarm (AWS Builder Loft SF)
Compliant with hack26 MCP specification & CrewAI supervised multi-agent architecture.
"""

import os
import asyncio
from crewai import Agent, Crew, Process, Task
from crewai.mcp import MCPServerHTTP

# Environment configuration:
# os.environ["YDC_API_KEY"] = "..."       # You.com: search + contents
# os.environ["ONE_API_KEY"] = "..."       # One: managed auth, 1000+ apps
# os.environ["PARASAIL_API_KEY"] = "..."  # Parasail: inference + embeddings
# os.environ["DISCORD_CHANNEL_ID"] = "1564842098740695100"

# 1. Connect scenario feed as MCPServerHTTP
# WARNING: Do NOT use the "https://..." string shorthand! Inside a running event loop
# the shorthand resolves to zero tools with no error. Always instantiate MCPServerHTTP.
scenario_mcp = MCPServerHTTP(
    url=os.environ.get("SCENARIO_MCP", "https://api.you.com/mcp/halloween-hack-26"),
    streamable=True,
    headers={},
)

# 2. Extract tools from MCP Server
# Tools available: hack26-get-tick, hack26-submit-containment, hack26-get-scoreboard
mcp_tools = scenario_mcp.get_tools()

# 3. Supervised Swarm Definition with Partial Knowledge
# Scout: ONLY sees raw sensor readings (emf, temp, motion)
sensor_scout = Agent(
    role="EMF & Thermal Telemetrist",
    goal="Identify anomalous electromagnetic spikes and subzero cold spots without knowing entity taxonomy",
    backstory="Specialist in paranormal sensor physics. Evaluates baseline noise vs genuine manifestation.",
    tools=[],
    verbose=True
)

# Parapsychologist: ONLY sees sighting metadata (entity_class, confidence, witnesses)
spectral_analyst = Agent(
    role="Cryptozoological Classifier",
    goal="Classify supernatural entity lethality according to the Spectral Codex",
    backstory="Paranormal researcher analyzing witness testimony reliability and ectoplasmic entity classes.",
    tools=[],
    verbose=True
)

# Marshal: ONLY sees civilian_status
civilian_marshal = Agent(
    role="Life-Safety Coordinator",
    goal="Determine if facility occupants are pinned or in immediate casualty danger",
    backstory="Facility egress coordinator with zero tolerance for civilian casualties.",
    tools=[],
    verbose=True
)

# Grid Engineer: ONLY sees containment_state
grid_engineer = Agent(
    role="Ward & Barrier Field Controller",
    goal="Evaluate salt-ward barrier integrity and breach risk",
    backstory="Engineer managing electromagnetic dampers and defensive wards.",
    tools=[],
    verbose=True
)

# Supervisor: Fuses partial intel, enforces budget <= 8 agents, submits containment
supervisor_arbiter = Agent(
    role="Swarm Containment Arbiter",
    goal="Arbitrate between 'contain', 'evacuate', 'observe' and report via hack26-submit-containment",
    backstory="Commander synthesizing partial reports while safeguarding venue false-alarm rating.",
    tools=mcp_tools,
    verbose=True
)

async def run_containment_loop():
    print(f"[*] Starting AetherSwarm for team: ${teamHandle}")
    
    while True:
        # Step 1: Pull incident tick
        tick = await scenario_mcp.call_tool("hack26-get-tick")
        print(f"[+] Pulled Tick #{tick['tick_id']} for facility: {tick['facility_id']}")
        
        # Verify budget constraints: exceeding max_active_agents is a scored failure
        max_agents = tick["swarm_budget"]["max_active_agents"]
        active_agents_count = 5
        if active_agents_count > max_agents:
            print(f"[!] BUDGET VIOLATION: {active_agents_count} > {max_agents}")
            
        # Step 2: Formulate containment action based on partial knowledge consensus
        # Priority 1: Civilians pinned + active threat -> 'evacuate'
        # Priority 2: Clear civilians + breached/holding wards -> 'contain'
        # Priority 3: Low confidence or sensor artifact -> 'observe'
        action = "observe"
        has_pinned = any("pinned" in r["civilian_status"].lower() for r in tick["sector_reports"])
        has_breach = any(r["containment_state"] == "breached" for r in tick["sector_reports"])
        
        if has_pinned:
            action = "evacuate"
        elif has_breach:
            action = "contain"
        else:
            action = "observe"
            
        # Step 3: Submit containment decision to scenario feed
        decision = await scenario_mcp.call_tool(
            "hack26-submit-containment",
            team="${teamHandle}",
            tick_id=tick["tick_id"],
            action=action   # contain | evacuate | observe
        )
        
        print(f"[✓] Judgment: Expected={decision.get('action_called_for')}, Score={decision.get('score')}, FalseAlarm={decision.get('is_false_alarm')}")
        
        # Check venue scoreboard
        scoreboard = await scenario_mcp.call_tool("hack26-get-scoreboard")
        print(f"[*] Current Standings updated ({len(scoreboard)} teams)")
        
        await asyncio.sleep(2)

if __name__ == "__main__":
    asyncio.run(run_containment_loop())
`;

  const handleCopy = () => {
    navigator.clipboard.writeText(pythonScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-950 border border-slate-800 rounded-xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <FileCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 font-mono">
                PYTHON MCP CLIENT // CREWAI SWARM RUNNER
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Ready-to-deploy Python code using MCPServerHTTP & hack26 tools
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Critical Implementation Warning Banner */}
        <div className="bg-amber-950/40 border-b border-amber-900/60 px-5 py-2.5 flex items-start gap-2.5 text-xs font-mono text-amber-200">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong>CRITICAL PROTOCOL NOTICE:</strong> Use{' '}
            <code className="text-white bg-amber-900/60 px-1 rounded">MCPServerHTTP</code>, not the{' '}
            <code className="text-white bg-amber-900/60 px-1 rounded">"https://..."</code> string shorthand. Inside a running event loop the shorthand resolves to zero tools with no error.
          </div>
        </div>

        {/* Code View Body */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950">
          <div className="relative">
            <button
              onClick={handleCopy}
              className="absolute top-3 right-3 flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3 py-1.5 rounded-md font-mono border border-slate-700 transition-colors shadow-md z-10"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-bold">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
            <pre className="text-xs font-mono text-slate-300 bg-slate-900/90 p-4 rounded-lg border border-slate-800 overflow-x-auto leading-relaxed">
              <code>{pythonScript}</code>
            </pre>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>Requires: <code className="text-slate-300">crewai[mcp] &gt;= 0.95.0</code></span>
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-white px-4 py-1.5 rounded font-mono text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
