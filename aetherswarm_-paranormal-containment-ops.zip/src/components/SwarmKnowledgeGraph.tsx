/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Activity,
  Ghost,
  Users,
  ShieldAlert,
  Radio,
  Cpu,
  Eye,
  EyeOff,
  CheckCircle,
  Wrench,
  ArrowRight,
  Sparkles,
  Lock,
} from 'lucide-react';
import { SWARM_AGENTS_CONFIG } from '../data/agentData.ts';
import { AgentExecutionState, ContainmentAction, ScenarioTick, SwarmDeliberationLog } from '../types/swarm.ts';

interface SwarmKnowledgeGraphProps {
  deliberation: SwarmDeliberationLog | null;
  currentTick: ScenarioTick | null;
  activeAgentIds: string[];
  onToggleAgent: (agentId: string) => void;
  selectedAgentId: string | null;
  onSelectAgent: (agentId: string) => void;
}

export const SwarmKnowledgeGraph: React.FC<SwarmKnowledgeGraphProps> = ({
  deliberation,
  currentTick,
  activeAgentIds,
  onToggleAgent,
  selectedAgentId,
  onSelectAgent,
}) => {
  const [activeTab, setActiveTab] = useState<'graph' | 'partial_matrix'>('graph');

  const getAgentState = (id: string): AgentExecutionState | undefined => {
    return deliberation?.agent_states?.find((s) => s.agent_id === id);
  };

  const getActionBadgeColor = (action?: ContainmentAction) => {
    switch (action) {
      case 'evacuate':
        return 'text-red-300 bg-red-950/80 border-red-700/80';
      case 'contain':
        return 'text-amber-300 bg-amber-950/80 border-amber-700/80';
      case 'observe':
        return 'text-emerald-300 bg-emerald-950/80 border-emerald-700/80';
      default:
        return 'text-slate-400 bg-slate-900 border-slate-800';
    }
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 flex flex-col">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-slate-800 gap-2 mb-3">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-emerald-400" />
          <h2 className="text-sm font-semibold tracking-wide text-slate-100 font-mono">
            SUPERVISED SWARM INTELLIGENCE BUS // PARTIAL KNOWLEDGE COORDINATION
          </h2>
        </div>

        {/* Tab switch */}
        <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 text-xs font-mono">
          <button
            onClick={() => setActiveTab('graph')}
            className={`px-2.5 py-1 rounded transition-colors ${
              activeTab === 'graph' ? 'bg-slate-800 text-slate-100 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Agent Swarm Graph
          </button>
          <button
            onClick={() => setActiveTab('partial_matrix')}
            className={`px-2.5 py-1 rounded transition-colors ${
              activeTab === 'partial_matrix' ? 'bg-slate-800 text-slate-100 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Partial Knowledge Matrix
          </button>
        </div>
      </div>

      {activeTab === 'graph' ? (
        <div className="flex flex-col gap-4">
          {/* Top Specialist Agents Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-2.5">
            {SWARM_AGENTS_CONFIG.filter((a) => a.id !== 'supervisor-overseer').map((agent) => {
              const state = getAgentState(agent.id);
              const isActive = activeAgentIds.includes(agent.id);
              const isSelected = selectedAgentId === agent.id;

              return (
                <div
                  key={agent.id}
                  onClick={() => onSelectAgent(agent.id)}
                  className={`relative rounded-lg border p-3 flex flex-col justify-between transition-all cursor-pointer ${
                    isSelected
                      ? 'border-emerald-500 bg-slate-900 shadow-md ring-1 ring-emerald-500/40'
                      : isActive
                      ? 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                      : 'border-slate-900 bg-slate-950/40 opacity-50'
                  }`}
                >
                  {/* Top Bar */}
                  <div className="flex items-center justify-between gap-1 mb-2">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <div
                        className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold"
                        style={{ backgroundColor: `${agent.color}20`, color: agent.color }}
                      >
                        {agent.callsign.split('-')[1]}
                      </div>
                      <div className="min-w-0">
                        <div className="text-[11px] font-bold text-slate-200 truncate font-mono">
                          {agent.callsign}
                        </div>
                        <div className="text-[9px] text-slate-400 truncate">{agent.title}</div>
                      </div>
                    </div>

                    {/* Active toggle */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleAgent(agent.id);
                      }}
                      className={`text-[9px] font-mono px-1.5 py-0.5 rounded border transition-colors ${
                        isActive
                          ? 'border-emerald-600 bg-emerald-950/80 text-emerald-300'
                          : 'border-slate-800 bg-slate-900 text-slate-500'
                      }`}
                      title="Toggle agent active status (affects swarm budget)"
                    >
                      {isActive ? 'ACTIVE' : 'OFFLINE'}
                    </button>
                  </div>

                  {/* Partial Intel Scope Badge */}
                  <div className="my-1.5 p-1.5 rounded bg-slate-950/80 border border-slate-800 text-[10px] font-mono">
                    <div className="text-slate-400 flex items-center gap-1 mb-0.5">
                      <Lock className="w-3 h-3 text-amber-400" />
                      <span className="font-semibold text-slate-300">Isolated Scope:</span>
                    </div>
                    <div className="text-slate-300 truncate">
                      {agent.id === 'agent-emf-scout' && 'sensors (emf, temp, mot)'}
                      {agent.id === 'agent-spectral-analyst' && 'sighting (class, conf)'}
                      {agent.id === 'agent-civilian-marshal' && 'civilian_status string'}
                      {agent.id === 'agent-grid-controller' && 'containment_state enum'}
                      {agent.id === 'agent-discord-relay' && 'escalation_channel'}
                    </div>
                  </div>

                  {/* Tool execution */}
                  {state?.last_tool_invoked && (
                    <div className="text-[10px] font-mono text-slate-400 flex items-center gap-1 mb-1.5">
                      <Wrench className="w-3 h-3 text-indigo-400" />
                      <span className="text-slate-300 truncate">Tool: {state.last_tool_invoked}()</span>
                    </div>
                  )}

                  {/* Vote Recommendation */}
                  <div className="mt-auto pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                    <span className="text-[10px] text-slate-400">Vote:</span>
                    {state?.recommended_action ? (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getActionBadgeColor(
                          state.recommended_action
                        )}`}
                      >
                        {state.recommended_action} ({(state.confidence * 100).toFixed(0)}%)
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-500">Standby</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Convergence Flow Line */}
          <div className="flex items-center justify-center my-0.5">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1 rounded-full">
              <span>5 Isolated Intelligence Vectors</span>
              <ArrowRight className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span className="text-emerald-400 font-semibold">Supervisor Fusion Engine</span>
            </div>
          </div>

          {/* Bottom Supervisor Arbiter Box */}
          <div className="bg-slate-900 border border-emerald-500/40 rounded-lg p-3.5 relative overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold font-mono text-xs">
                  S-0
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 font-mono flex items-center gap-2">
                    SUPERVISOR ARBITER (OVERSEER-PRIME)
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-semibold">
                      TOOL: hack26-submit-containment
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Fuses isolated agent telemetry • Enforces active agent budget ({activeAgentIds.length}/8) • Dispatches Discord & MCP
                  </div>
                </div>
              </div>

              {/* Final Consensus Action */}
              <div className="flex items-center gap-2 font-mono">
                <span className="text-xs text-slate-400">Swarm Verdict:</span>
                <span
                  className={`text-xs font-bold px-3 py-1 rounded border uppercase tracking-wider ${getActionBadgeColor(
                    deliberation?.supervisor_verdict
                  )}`}
                >
                  {deliberation?.supervisor_verdict || 'AWAITING INCIDENT TICK'}
                </span>
              </div>
            </div>

            {/* Deliberation Text */}
            <div className="text-xs text-slate-300 font-mono bg-slate-950 p-2.5 rounded border border-slate-800/80 leading-relaxed">
              {deliberation?.consensus_summary || (
                <span className="text-slate-500 italic">
                  Press 'Step' or 'Auto-Run' above to pull the next incident tick from the scenario feed and watch the swarm coordinate containment...
                </span>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Partial Knowledge Isolation Matrix */
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="p-2">Agent Role</th>
                <th className="p-2">Accessible Field(s)</th>
                <th className="p-2">Shielded / Hidden Information</th>
                <th className="p-2">Domain Specialization Tools</th>
                <th className="p-2">Failure Risk If Operating Alone</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="p-2 font-bold text-cyan-400">Sensor Scout (01)</td>
                <td className="p-2 text-emerald-400 font-semibold">sensors: emf, temp, motion</td>
                <td className="p-2 text-red-400">entity_class, civilians, wards</td>
                <td className="p-2 text-slate-300">detect_thermal_inversion, analyze_emf_spikes</td>
                <td className="p-2 text-slate-400">Falsely alarms on microwaves or server coils</td>
              </tr>
              <tr>
                <td className="p-2 font-bold text-purple-400">Spectral Analyst (02)</td>
                <td className="p-2 text-emerald-400 font-semibold">sighting: class, conf, witnesses</td>
                <td className="p-2 text-red-400">emf readings, civilian pinned status</td>
                <td className="p-2 text-slate-300">query_spectral_codex, verify_witness_veracity</td>
                <td className="p-2 text-slate-400">Cannot verify if civilians are pinned in room</td>
              </tr>
              <tr>
                <td className="p-2 font-bold text-amber-400">Civilian Marshal (03)</td>
                <td className="p-2 text-emerald-400 font-semibold">civilian_status string</td>
                <td className="p-2 text-red-400">entity taxonomy, EMF field sensors</td>
                <td className="p-2 text-slate-300">parse_trapped_headcount, assess_casualty_risk</td>
                <td className="p-2 text-slate-400">Cannot distinguish real ghost from benign echo</td>
              </tr>
              <tr>
                <td className="p-2 font-bold text-blue-400">Grid Controller (04)</td>
                <td className="p-2 text-emerald-400 font-semibold">containment_state enum</td>
                <td className="p-2 text-red-400">witness sightings, thermal sensors</td>
                <td className="p-2 text-slate-300">calculate_barrier_overcharge, check_ward</td>
                <td className="p-2 text-slate-400">May lock down rooms containing trapped people</td>
              </tr>
              <tr>
                <td className="p-2 font-bold text-emerald-400">Supervisor Arbiter</td>
                <td className="p-2 text-emerald-300 font-semibold">Unified Specialist Vectors</td>
                <td className="p-2 text-slate-400">Raw noisy telemetry (pre-filtered by specialists)</td>
                <td className="p-2 text-slate-300">fuse_intel, enforce_budget, submit_containment</td>
                <td className="p-2 text-slate-400">Requires multi-agent consensus to avoid hallucinations</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
