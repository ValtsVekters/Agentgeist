/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Terminal,
  Server,
  Code,
  Sliders,
  AlertTriangle,
} from 'lucide-react';
import { ScenarioTick } from '../types/swarm.ts';
import { scenarioMcpService } from '../services/mcpClient.ts';

interface TickInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  tick: ScenarioTick | null;
  onRefreshMcp: () => void;
}

export const TickInspectorModal: React.FC<TickInspectorModalProps> = ({
  isOpen,
  onClose,
  tick,
  onRefreshMcp,
}) => {
  const [copied, setCopied] = useState(false);
  const currentConfig = scenarioMcpService.getRemoteMcpConfig();
  const [remoteUrl, setRemoteUrl] = useState(currentConfig.url);
  const [useRemote, setUseRemote] = useState(currentConfig.enabled);
  const [statusMsg, setStatusMsg] = useState('');

  if (!isOpen) return null;

  const handleCopyJson = () => {
    if (!tick) return;
    navigator.clipboard.writeText(JSON.stringify(tick, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveConfig = () => {
    scenarioMcpService.setRemoteMcpUrl(remoteUrl, useRemote);
    setStatusMsg('MCP Configuration updated successfully.');
    setTimeout(() => setStatusMsg(''), 2500);
    onRefreshMcp();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-950 border border-slate-800 rounded-xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="text-sm font-bold text-slate-100 font-mono">
                TICK CONTRACT INSPECTOR & MCP SERVER CONFIG
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Inspect raw Scenario Feed payload or link external SCENARIO_MCP
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Remote MCP Setting */}
        <div className="p-4 bg-slate-900/40 border-b border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-200 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-cyan-400" />
              Scenario MCP Endpoint (SCENARIO_MCP)
            </span>
            <label className="flex items-center gap-2 text-xs font-mono text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={useRemote}
                onChange={(e) => setUseRemote(e.target.checked)}
                className="rounded bg-slate-950 border-slate-700 text-emerald-600 focus:ring-0"
              />
              <span>Connect Remote MCP</span>
            </label>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="e.g. http://127.0.0.1:8000/sse or https://scenario-feed.venue/mcp"
              value={remoteUrl}
              onChange={(e) => setRemoteUrl(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-mono focus:border-emerald-500 focus:outline-none"
            />
            <button
              onClick={handleSaveConfig}
              className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded text-xs font-mono font-semibold transition-colors"
            >
              Apply
            </button>
          </div>

          {statusMsg && (
            <div className="text-[11px] text-emerald-400 font-mono mt-1">{statusMsg}</div>
          )}

          <div className="text-[10px] text-slate-500 font-mono">
            Default: Built-in Venue Scenario Engine running AWS Builder Loft SF simulation with live ground-truth grading.
          </div>
        </div>

        {/* Raw Contract JSON View */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950 flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-mono">
              Raw Payload for Tick #{tick?.tick_id || 142}:
            </span>
            <button
              onClick={handleCopyJson}
              className="flex items-center gap-1 text-[11px] font-mono text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2 py-1 rounded transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy JSON</span>
                </>
              )}
            </button>
          </div>

          <pre className="flex-1 text-xs font-mono text-emerald-400/90 bg-slate-900/90 p-4 rounded-lg border border-slate-800 overflow-x-auto leading-relaxed">
            <code>{JSON.stringify(tick, null, 2)}</code>
          </pre>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>Fixed fields: <code>sector_reports</code>, <code>civilian_status</code>, <code>containment_state</code></span>
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-white px-4 py-1.5 rounded font-mono text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
