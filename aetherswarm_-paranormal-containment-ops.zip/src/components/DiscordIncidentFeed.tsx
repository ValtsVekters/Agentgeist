/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  MessageSquare,
  Hash,
  Copy,
  Check,
  Send,
  ExternalLink,
  ShieldAlert,
  Bot,
  Radio,
  Sparkles,
} from 'lucide-react';
import { DiscordTacticalMessage } from '../types/swarm.ts';
import { VENUE_DISCORD_CHANNEL, VENUE_DISCORD_CHANNEL_ID } from '../data/facilityData.ts';

interface DiscordIncidentFeedProps {
  messages: DiscordTacticalMessage[];
  teamHandle: string;
}

export const DiscordIncidentFeed: React.FC<DiscordIncidentFeedProps> = ({
  messages,
  teamHandle,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopyEvidence = (msg: DiscordTacticalMessage) => {
    const markdown = `**[${msg.channel} // TACTICAL EVIDENCE FOR JUDGES]**
Tick ID: #${msg.tick_id} | Channel ID: ${msg.channel_id}
Author: ${msg.author.name}
Verdict: ${msg.embed.title}
${msg.embed.description}

Specialist Intel:
${msg.embed.fields.find((f) => f.name === 'Specialist Intel Vectors')?.value || 'N/A'}

${msg.embed.footer.text}`;

    navigator.clipboard.writeText(markdown);
    setCopiedId(msg.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="bg-[#1e1f22] border border-slate-800 rounded-lg flex flex-col h-full overflow-hidden text-[#dbdee1]">
      {/* Discord Header Bar */}
      <div className="bg-[#2b2d31] px-3.5 py-2.5 border-b border-[#1f2023] flex items-center justify-between text-xs font-sans">
        <div className="flex items-center gap-2">
          <Hash className="w-4 h-4 text-[#80848e]" />
          <span className="font-semibold text-white tracking-wide">{VENUE_DISCORD_CHANNEL.replace('#', '')}</span>
          <span className="text-[10px] text-[#949ba4] font-mono border-l border-[#3f4147] pl-2">
            ID: {VENUE_DISCORD_CHANNEL_ID}
          </span>
          <span className="text-[10px] bg-[#232428] text-emerald-400 px-1.5 py-0.5 rounded font-mono font-semibold">
            via one-mcp
          </span>
        </div>
        <div className="text-[11px] text-[#949ba4] font-mono hidden sm:inline">
          Room Evidence Channel
        </div>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[500px]">
        {messages.length === 0 ? (
          <div className="text-center py-12 text-[#949ba4] text-xs font-mono">
            <Radio className="w-8 h-8 mx-auto mb-2 text-[#4e5058] animate-pulse" />
            <p>Awaiting tactical incident dispatches from swarm coordinator...</p>
            <p className="text-[11px] text-[#4e5058] mt-1">
              Dispatches posted to {VENUE_DISCORD_CHANNEL} serve as verification evidence for venue judges.
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const embedBorderColor =
              msg.embed.color === 0xef4444
                ? '#ef4444' // Red
                : msg.embed.color === 0xf59e0b
                ? '#f59e0b' // Amber
                : '#10b981'; // Green

            return (
              <div key={msg.id} className="flex gap-3 text-xs group hover:bg-[#2e3035]/40 p-2 rounded -mx-2 transition-colors">
                {/* Bot Avatar */}
                <div className="w-9 h-9 rounded-full bg-emerald-700/80 flex items-center justify-center text-white font-mono font-bold shrink-0">
                  <ShieldAlert className="w-5 h-5 text-emerald-200" />
                </div>

                {/* Message Body */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold text-white hover:underline cursor-pointer">
                      {msg.author.name}
                    </span>
                    <span className="bg-[#5865f2] text-white text-[9px] font-bold px-1 rounded uppercase flex items-center gap-0.5">
                      <Bot className="w-2.5 h-2.5" /> BOT
                    </span>
                    <span className="text-[10px] text-[#949ba4]">{msg.timestamp}</span>

                    {/* Copy Evidence Button */}
                    <button
                      onClick={() => handleCopyEvidence(msg)}
                      className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity text-[10px] flex items-center gap-1 bg-[#2b2d31] hover:bg-[#35373c] text-[#dbdee1] px-2 py-0.5 rounded border border-[#3f4147]"
                      title="Copy tactical incident evidence for judges"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400 font-semibold">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy Evidence</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="text-[#dbdee1] mb-2 leading-relaxed">
                    {msg.content}
                  </div>

                  {/* Rich Tactical Embed */}
                  <div
                    className="bg-[#2b2d31] rounded p-3 border-l-4 text-xs font-sans space-y-2 shadow-sm"
                    style={{ borderLeftColor: embedBorderColor }}
                  >
                    <div className="font-bold text-white tracking-wide text-xs">
                      {msg.embed.title}
                    </div>

                    <div className="text-[#b5bac1] leading-relaxed text-[11px]">
                      {msg.embed.description}
                    </div>

                    {/* Embed Fields */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 border-t border-[#35373c]">
                      {msg.embed.fields
                        .filter((f) => f.name !== 'Specialist Intel Vectors')
                        .map((f, i) => (
                          <div key={i} className="text-[10px]">
                            <div className="text-[#949ba4] font-semibold uppercase">{f.name}</div>
                            <div className="text-[#dbdee1] font-mono mt-0.5 whitespace-pre-line">
                              {f.value}
                            </div>
                          </div>
                        ))}
                    </div>

                    {/* Specialist Intel Breakdown Field */}
                    {msg.embed.fields.find((f) => f.name === 'Specialist Intel Vectors') && (
                      <div className="pt-2 border-t border-[#35373c] text-[10px] font-mono">
                        <div className="text-[#949ba4] font-semibold uppercase mb-1">
                          Specialist Swarm Telemetry Vectors:
                        </div>
                        <div className="text-[#dbdee1] whitespace-pre-line bg-[#1e1f22] p-2 rounded border border-[#35373c]/80 leading-relaxed">
                          {msg.embed.fields.find((f) => f.name === 'Specialist Intel Vectors')?.value}
                        </div>
                      </div>
                    )}

                    {/* Footer */}
                    <div className="text-[9px] text-[#949ba4] font-mono pt-1">
                      {msg.embed.footer.text}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Discord Input Bar (Read-only simulation indicator) */}
      <div className="p-3 bg-[#2b2d31] border-t border-[#1f2023] flex items-center gap-2">
        <div className="flex-1 bg-[#383a40] rounded px-3 py-1.5 text-xs text-[#949ba4] flex items-center justify-between font-mono">
          <span>Posting via one-mcp daemon to #loft-incident (ID: 1564842098740695100)...</span>
          <span className="text-[10px] text-emerald-400">● Live Bridge</span>
        </div>
      </div>
    </div>
  );
};
