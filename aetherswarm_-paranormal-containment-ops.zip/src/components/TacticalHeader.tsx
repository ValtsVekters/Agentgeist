/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
  Play,
  Pause,
  SkipForward,
  RotateCcw,
  Zap,
  Terminal,
  Activity,
  Code2,
  Users,
  AlertTriangle,
  Building2,
  Radio,
} from 'lucide-react';
import { SwarmBudget } from '../types/swarm.ts';
import { FACILITY_NAME } from '../data/facilityData.ts';

interface TacticalHeaderProps {
  tickId: number;
  teamHandle: string;
  onTeamChange: (team: string) => void;
  isRunning: boolean;
  onToggleRun: () => void;
  onStepTick: () => void;
  onReset: () => void;
  speed: number;
  onSpeedChange: (speed: number) => void;
  budget: SwarmBudget;
  activeAgentCount: number;
  onSelectScenario: (scenarioIndex: number) => void;
  onOpenMcpModal: () => void;
  onOpenPythonModal: () => void;
}

export const TacticalHeader: React.FC<TacticalHeaderProps> = ({
  tickId,
  teamHandle,
  onTeamChange,
  isRunning,
  onToggleRun,
  onStepTick,
  onReset,
  speed,
  onSpeedChange,
  budget,
  activeAgentCount,
  onSelectScenario,
  onOpenMcpModal,
  onOpenPythonModal,
}) => {
  const [isEditingTeam, setIsEditingTeam] = useState(false);
  const [tempTeam, setTempTeam] = useState(teamHandle);

  const isOverBudget = activeAgentCount > budget.max_active_agents;

  const handleSaveTeam = () => {
    onTeamChange(tempTeam);
    setIsEditingTeam(false);
  };

  return (
    <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur sticky top-0 z-30 px-4 py-2.5">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Left: Branding & Facility context */}
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            <ShieldAlert className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-100 tracking-wide text-sm font-mono">
                AETHERSWARM
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/50 font-mono">
                LIVE MCP FEED
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <Building2 className="w-3.5 h-3.5 text-slate-500" />
              <span>{FACILITY_NAME}</span>
            </div>
          </div>
        </div>

        {/* Center: Live Tick Status & Budget Constraints */}
        <div className="flex items-center gap-4 text-xs">
          {/* Tick Badge */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-md">
            <span className="text-slate-400 uppercase tracking-wider font-mono text-[11px]">TICK:</span>
            <span className="font-mono font-bold text-emerald-400 text-sm">#{tickId}</span>
          </div>

          {/* Team Handle */}
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-md">
            <span className="text-slate-400 text-[11px] font-mono">TEAM:</span>
            {isEditingTeam ? (
              <div className="flex items-center gap-1">
                <input
                  type="text"
                  value={tempTeam}
                  onChange={(e) => setTempTeam(e.target.value)}
                  className="bg-slate-950 border border-emerald-500 text-emerald-300 px-1 py-0.5 rounded text-xs w-20 font-mono"
                  autoFocus
                />
                <button
                  onClick={handleSaveTeam}
                  className="text-[10px] bg-emerald-600 hover:bg-emerald-500 text-white px-1.5 py-0.5 rounded"
                >
                  OK
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsEditingTeam(true)}
                className="font-mono font-semibold text-emerald-300 hover:text-emerald-200 underline decoration-dotted text-xs"
                title="Click to edit team handle"
              >
                {teamHandle}
              </button>
            )}
          </div>

          {/* Swarm Budget Meter */}
          <div
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md border ${
              isOverBudget
                ? 'bg-red-950/40 border-red-500/50 text-red-300'
                : 'bg-slate-900 border-slate-800 text-slate-300'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[11px] text-slate-400 font-mono">AGENTS:</span>
            <span
              className={`font-mono font-bold ${
                isOverBudget ? 'text-red-400' : 'text-emerald-400'
              }`}
            >
              {activeAgentCount}/{budget.max_active_agents}
            </span>
            {isOverBudget ? (
              <span className="flex items-center gap-1 text-[10px] text-red-400 font-semibold uppercase">
                <AlertTriangle className="w-3 h-3" /> Budget Exceeded!
              </span>
            ) : (
              <span className="text-[10px] text-slate-500 font-mono">Compliant</span>
            )}
          </div>

          {/* Credits Remaining */}
          <div className="hidden md:flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-md text-slate-300">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px] text-slate-400 font-mono">CREDITS:</span>
            <span className="font-mono text-amber-300 font-semibold">
              {budget.api_credits_remaining.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Right: Simulation Controls & Modal Triggers */}
        <div className="flex items-center gap-2">
          {/* Quick Scenario Injector */}
          <select
            onChange={(e) => onSelectScenario(Number(e.target.value))}
            className="bg-slate-900 border border-slate-800 text-slate-300 text-xs px-2.5 py-1.5 rounded-md focus:border-emerald-500 focus:outline-none font-mono"
            defaultValue=""
          >
            <option value="" disabled>
              ⚡ Inject Scenario...
            </option>
            <option value="0">1. Coffee Bar Phantom (Prompt Default)</option>
            <option value="1">2. Auditorium Poltergeist (Empty Hall)</option>
            <option value="2">3. Server Microwave (False Alarm Test)</option>
            <option value="3">4. Basement Banshee + Dock (Multi-Sector)</option>
            <option value="4">5. Executive Suite Wards Holding</option>
            <option value="5">6. Hackathon Pit Psychic Echo</option>
            <option value="6">7. Multi-Sector Coordinated Swarm</option>
          </select>

          {/* Step Button */}
          <button
            onClick={onStepTick}
            disabled={isRunning}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 text-xs px-2.5 py-1.5 rounded-md font-mono"
            title="Step next tick"
          >
            <SkipForward className="w-3.5 h-3.5" />
            <span>Step</span>
          </button>

          {/* Play/Pause Button */}
          <button
            onClick={onToggleRun}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-md transition-colors font-mono ${
              isRunning
                ? 'bg-amber-600 hover:bg-amber-500 text-white'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950/50'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>Auto-Run</span>
              </>
            )}
          </button>

          {/* Speed selector */}
          <div className="hidden sm:flex items-center border border-slate-800 rounded-md overflow-hidden bg-slate-900 text-[11px] font-mono">
            {[1, 2, 5].map((s) => (
              <button
                key={s}
                onClick={() => onSpeedChange(s)}
                className={`px-2 py-1 transition-colors ${
                  speed === s
                    ? 'bg-emerald-950 text-emerald-300 font-bold border-b-2 border-emerald-500'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s}x
              </button>
            ))}
          </div>

          {/* Python CrewAI MCP Script Modal Button */}
          <button
            onClick={onOpenPythonModal}
            className="flex items-center gap-1 bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs px-2.5 py-1.5 rounded-md font-mono"
            title="View Python MCPServerHTTP implementation code"
          >
            <Code2 className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden lg:inline">Python MCP</span>
          </button>
        </div>
      </div>
    </header>
  );
};
